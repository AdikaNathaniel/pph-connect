import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { projectId } = await req.json();
    
    if (!projectId) {
      return new Response(
        JSON.stringify({ error: 'Project ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch project details
    const { data: project, error: projectError } = await supabase
      .from('projects')
      .select('*')
      .eq('id', projectId)
      .single();

    if (projectError || !project) {
      throw new Error('Project not found');
    }

    console.log('Loading questions for project:', project.name);

    // Extract sheet ID and GID from URL
    const sheetIdMatch = project.google_sheet_url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    const gidMatch = project.google_sheet_url.match(/[#&]gid=([0-9]+)/);
    
    if (!sheetIdMatch) {
      throw new Error('Invalid Google Sheets URL');
    }

    const sheetId = sheetIdMatch[1];
    const gid = gidMatch ? gidMatch[1] : '0';
    
    // Fetch CSV data (Service Account first, fallback to public)
    const serviceAccountKey = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_KEY');
    const googleClientEmail = Deno.env.get('GOOGLE_CLIENT_EMAIL');
    const googlePrivateKey = Deno.env.get('GOOGLE_PRIVATE_KEY');

    async function getAccessTokenFromSA(saJson: any): Promise<string> {
      const header = { alg: 'RS256', typ: 'JWT' };
      const now = Math.floor(Date.now() / 1000);
      const payload = {
        iss: saJson.client_email,
        scope: 'https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/spreadsheets.readonly',
        aud: 'https://oauth2.googleapis.com/token',
        iat: now,
        exp: now + 3600
      };
      const enc = (obj: any) => btoa(JSON.stringify(obj)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
      const toUint8 = (s: string) => new TextEncoder().encode(s);
      const importKey = async (pem: string) => {
        const pemBody = pem.replace('-----BEGIN PRIVATE KEY-----', '').replace('-----END PRIVATE KEY-----', '').replace(/\n/g, '');
        const binaryDer = Uint8Array.from(atob(pemBody), c => c.charCodeAt(0));
        return await crypto.subtle.importKey('pkcs8', binaryDer, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
      };
      const unsigned = `${enc(header)}.${enc(payload)}`;
      const key = await importKey(saJson.private_key);
      const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, toUint8(unsigned));
      const sigB64 = btoa(String.fromCharCode(...new Uint8Array(signature))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
      const assertion = `${unsigned}.${sigB64}`;

      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion })
      });
      if (!tokenRes.ok) throw new Error(`Failed to obtain Google access token: ${tokenRes.status}`);
      const tokenJson = await tokenRes.json();
      return tokenJson.access_token;
    }

    let csvText: string;
    try {
      let credentials: any | null = null;
      
      // Try individual secrets first (easier to manage)
      if (googleClientEmail && googlePrivateKey) {
        credentials = {
          client_email: googleClientEmail,
          private_key: googlePrivateKey
        };
        console.log('Using individual Google secrets for populate:', credentials.client_email);
      } 
      // Fallback to full JSON
      else if (serviceAccountKey) {
        try { 
          credentials = JSON.parse(serviceAccountKey); 
          console.log('Using full JSON service account for populate:', credentials.client_email);
        } catch { 
          console.log('Failed to parse GOOGLE_SERVICE_ACCOUNT_KEY');
        }
      }

      if (credentials) {
        const accessToken = await getAccessTokenFromSA(credentials);
        const driveExportUrl = `https://www.googleapis.com/drive/v3/files/${sheetId}/export?mimeType=text/csv&gid=${gid}`;
        const res = await fetch(driveExportUrl, { headers: { Authorization: `Bearer ${accessToken}` } });
        if (!res.ok) throw new Error(`Drive export failed with ${res.status}. Ensure the sheet is shared with ${credentials.client_email}.`);
        csvText = await res.text();
      } else {
        const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=${gid}`;
        const response = await fetch(csvUrl);
        if (!response.ok) throw new Error(`Failed to fetch sheet: ${response.status}`);
        csvText = await response.text();
      }
    } catch (err) {
      throw err;
    }

    const lines = csvText.trim().split('\n');
    
    if (lines.length <= 1) {
      throw new Error('Sheet has no data rows');
    }
    
    // Proper CSV parser that handles quoted fields with commas
    const parseCSVLine = (line: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        const nextChar = line[i + 1];
        
        if (char === '"') {
          if (inQuotes && nextChar === '"') {
            // Escaped quote
            current += '"';
            i++; // Skip next quote
          } else {
            // Toggle quote mode
            inQuotes = !inQuotes;
          }
        } else if (char === ',' && !inQuotes) {
          // Field separator (only when not in quotes)
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      
      // Add the last field
      result.push(current.trim());
      
      return result;
    };
    
    // Parse headers
    const headers = parseCSVLine(lines[0]).filter(h => h);
    console.log('Parsed headers:', headers);
    
    // Get template config
    const { data: template } = await supabase
      .from('task_templates')
      .select('column_config')
      .eq('id', project.template_id)
      .single();

    const columnConfig = template?.column_config || [];
    
    // Create question records for each row
    const questions = [];
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i]);
      console.log(`Row ${i} parsed values:`, values);
      const questionData: Record<string, any> = {};
      
      headers.forEach((header, index) => {
        questionData[header] = values[index] || '';
      });
      
      // Generate unique question ID
      const { data: questionId, error: questionIdError } = await supabase.rpc('generate_question_id', { project_name: project.name });
      
      if (questionIdError) {
        console.error('Error generating question ID:', questionIdError);
        throw questionIdError;
      }
      
      questions.push({
        project_id: projectId,
        question_id: questionId,
        row_index: i,
        data: questionData,
        required_replications: project.replications_per_question || 1,
        completed_replications: 0,
        is_answered: false
      });
    }
    
    console.log(`Creating ${questions.length} questions for project ${projectId}`);
    
    // Delete existing questions for this project (in case of reload)
    console.log('Deleting existing questions for project:', projectId);
    const { error: deleteError } = await supabase.from('questions').delete().eq('project_id', projectId);
    if (deleteError) {
      console.error('Error deleting existing questions:', deleteError);
    }
    
    // Insert questions in batches
    const batchSize = 100;
    for (let i = 0; i < questions.length; i += batchSize) {
      const batch = questions.slice(i, i + batchSize);
      console.log(`Inserting question batch ${Math.floor(i/batchSize) + 1}, questions ${i + 1}-${Math.min(i + batchSize, questions.length)}`);
      const { error: insertError } = await supabase
        .from('questions')
        .insert(batch);
      
      if (insertError) {
        console.error('Error inserting question batch:', insertError);
        throw insertError;
      }
    }
    
    // Update project task counts
    await supabase
      .from('projects')
      .update({ 
        total_tasks: questions.length,
        completed_tasks: 0
      })
      .eq('id', projectId);
    
    console.log(`Successfully loaded ${questions.length} questions`);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        questionsLoaded: questions.length 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Error in populate-project-questions:', error);
    
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Internal server error'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
