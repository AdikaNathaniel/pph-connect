Okay, let's continue with the dashboard. 
Look at @https://ui.shadcn.com/examples/dashboard (screenshot)
looking at their code, they have an acutal header inside that main (main is right of sidebar)
1) Let's implement that, too. Make sure the borders align in height: header bottom border, and the sidebar's border underneath the logo. They must ALWAYS align. 

2) Lastly I want you to move our "Quick Create" button to the right side of that header. Possible? 
Again, this will be part of the design system and will be recplicated across all (Manager UI side facing) pages. To make sure the page title is not too close to the top of actual page, we may want to increase the sidebar's logo section slightly and kinda meet in the middle if that makes sense.
@Design Pricniples.md 