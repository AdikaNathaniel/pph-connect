border-bottom-color: oklch(0.922 0 0);
border-left-color: rgba(226, 232, 240, 0.7);

color(srgb 0.9224 0.9359 0.9576) !important

#dfe4ed

#dfe4ed

inner login 
#f4f6f9

outer login
#e1e1e1

reference
#e5e5e5