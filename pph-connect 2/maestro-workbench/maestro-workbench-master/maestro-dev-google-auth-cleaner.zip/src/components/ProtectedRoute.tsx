import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: 'manager' | 'worker';
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredRole }) => {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  // Enforce password change flow if required
  const needsPasswordChange = !!user?.initial_password_hash && !user?.password_changed_at;
  if (needsPasswordChange && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }

  if (requiredRole) {
    // Root users can access manager routes, but managers cannot access worker routes
    if (requiredRole === 'manager' && !(user?.role === 'manager' || user?.role === 'root')) {
      return <Navigate to="/w/dashboard" replace />;
    }
    if (requiredRole === 'worker' && user?.role !== 'worker') {
      return <Navigate to="/m/dashboard" replace />;
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;