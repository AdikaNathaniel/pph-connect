import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LogOut, User, BarChart3 } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const getRoleBadgeColor = (role: string) => {
    return role === 'manager' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground';
  };

  const isManager = user?.role === 'manager' || user?.role === 'root';

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-lg font-semibold">
            <Link to={isManager ? "/m/dashboard" : "/w/dashboard"} className="hover:text-primary transition-colors">
              Maestro
            </Link>
          </h1>
          <nav className="flex items-center space-x-2">
            {isManager && (
              <Button 
                variant={location.pathname === '/m/analytics' ? 'default' : 'ghost'} 
                size="sm" 
                asChild
              >
                <Link to="/m/analytics">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Stats
                </Link>
              </Button>
            )}
            {!isManager && (
              <Button 
                variant={location.pathname === '/w/analytics' ? 'default' : 'ghost'} 
                size="sm" 
                asChild
              >
                <Link to="/w/analytics">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics
                </Link>
              </Button>
            )}
          </nav>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4" />
            <span className="text-sm font-medium">{user?.full_name}</span>
            <Badge className={getRoleBadgeColor(user?.role || '')}>
              {user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)}
            </Badge>
          </div>
          
          <Button variant="ghost" size="sm" onClick={logout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;