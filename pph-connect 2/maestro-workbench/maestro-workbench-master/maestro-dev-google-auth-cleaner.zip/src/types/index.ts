export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'manager' | 'worker' | 'root';
  initial_password_hash?: string;
  password_changed_at?: string;
  last_sign_in_at?: string;
  suspended?: boolean;
  created_at: string;
  updated_at: string;
}

// Modality types for task templates
export type Modality = 
  | 'spreadsheet'   // Current spreadsheet-based tasks (no ontology needed)
  | 'audio-short'   // Audio playback + form fields (transcription, sentiment, etc.)
  | 'audio-long'    // Audio waveform annotation (timestamps, segments, speaker labels)
  | 'text'          // Text annotation tasks
  | 'image'         // Image annotation tasks
  | 'video'         // Video annotation tasks
  | 'multimodal';   // Mixed media tasks

// Label ontology for annotation tasks (optional - only for non-spreadsheet modalities)
export interface LabelOntology {
  name: string;
  description: string;
  categories: {
    id: string;
    name: string;
    labels: {
      id: string;
      name: string;
      color: string;
      description?: string;
      shortcut?: string;
      // Nested labels support (e.g., PII → ID → Name)
      children?: {
        id: string;
        name: string;
        color: string;
        description?: string;
        shortcut?: string;
      }[];
    }[];
    multiSelect: boolean;
    required: boolean;
  }[];
  hierarchical?: {
    enabled: boolean;
    parentChild: Record<string, string[]>;
  };
}

// Modality-specific configurations
export interface ModalityConfig {
  // Spreadsheet modality (current) - uses column_config as-is
  spreadsheet?: Record<string, never>; // Empty object
  
  // Audio shortform configuration (simple playback + form)
  'audio-short'?: {
    fileFormats: string[];
    quality: 'high' | 'standard';
    storageUrl: string;
    transcriptionRequired: boolean;
    playbackControls: {
      speed: boolean;
      loop: boolean;
      rewind: boolean;
    };
  };
  
  // Audio longform configuration (waveform annotation)
  'audio-long'?: {
    fileFormats: string[];
    quality: 'high' | 'standard';
    storageUrl: string;
    waveformControls: {
      zoom: boolean;
      segment: boolean;
      speaker: boolean;
      transcription: boolean;
    };
    timestampPrecision: 'second' | 'millisecond';
  };
  
  // Text modality configuration
  text?: {
    maxLength: number;
    minLength: number;
    allowMarkdown: boolean;
  };
  
  // Image modality configuration
  image?: {
    fileFormats: string[];
    maxResolution: string;
    annotationTools: string[];
  };
  
  // Video modality configuration
  video?: {
    fileFormats: string[];
    maxDuration: number;
    playbackControls: {
      speed: boolean;
      frame: boolean;
    };
  };
}

export interface TaskTemplate {
  id: string;
  name: string;
  description?: string;
  google_sheet_url: string;
  column_config: ColumnConfig[];
  modality: Modality;
  modality_config: ModalityConfig;
  label_ontology?: LabelOntology | null; // Optional - only for annotation modalities
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  instructions?: string;
  instructions_pdf_url?: string;
  instructions_google_docs_url?: string;
  template_id: string;
  language?: string;
  locale?: string;
  status: 'active' | 'paused' | 'completed';
  google_sheet_url: string;
  total_tasks: number;
  completed_tasks: number;
  reservation_time_limit_minutes: number;
  average_handle_time_minutes: number | null;
  enable_skip_button: boolean;
  skip_reasons: string[];
  due_date?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  training_module_id?: string | null;
  training_required: boolean;
}

export interface ProjectAssignment {
  id: string;
  worker_id: string;
  project_id: string;
  assigned_by: string;
  assigned_at: string;
  priority: number;
}

export interface ColumnConfig {
  id: string;
  name: string;
  columnLetter?: string;
  type: 'read' | 'write';
  hidden?: boolean;
  inputType?: 'text' | 'textarea' | 'select' | 'radio' | 'rating' | 'number';
  options?: string[];
  optionColors?: Record<string, string>;
  required?: boolean;
  conditional?: {
    dependsOnColumn: string;
    requiredValue: string;
  };
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
  pasteDetection?: boolean;
  pastePreventionEnabled?: boolean;
  tooltip?: string;
}

export interface Task {
  id: string;
  project_id: string;
  row_index: number;
  data: Record<string, unknown>;
  status: 'pending' | 'assigned' | 'in_progress' | 'completed';
  assigned_to?: string;
  assigned_at?: string;
  completed_at?: string;
  completion_time_seconds?: number;
  created_at: string;
  updated_at: string;
}

export interface TaskAssignment {
  taskId: string;
  workerId: string;
  assignedAt: string;
  expiresAt: string;
}

export interface TrainingCompletion {
  id: string;
  worker_id: string;
  training_module_id: string;
  project_id: string;
  started_at: string | null;
  completed_at: string | null;
  duration_seconds: number | null;
}