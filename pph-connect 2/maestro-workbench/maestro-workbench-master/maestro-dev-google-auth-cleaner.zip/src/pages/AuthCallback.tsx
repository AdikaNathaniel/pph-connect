import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const AuthCallback = () => {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleOAuthCallback = async () => {
      try {
        // Get the OAuth session from the URL hash
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) {
          throw sessionError;
        }

        if (!session) {
          throw new Error('No session found after OAuth callback');
        }

        // Get the user's profile to determine their role
        let { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('role, suspended, id, email, full_name')
          .eq('id', session.user.id)
          .single();

        // If profile doesn't exist, auto-create as worker (first-time OAuth user)
        if (profileError?.code === 'PGRST116') {
          const newProfile = {
            id: session.user.id,
            email: session.user.email || '',
            full_name: session.user.user_metadata?.full_name ||
                      session.user.user_metadata?.name ||
                      session.user.email?.split('@')[0] ||
                      'New User',
            role: 'worker',
            password_changed_at: new Date().toISOString(), // OAuth users don't need password changes
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };

          const { data: createdProfile, error: createError } = await supabase
            .from('profiles')
            .insert(newProfile)
            .select('role, suspended, id, email, full_name')
            .single();

          if (createError) {
            console.error('Failed to create profile:', createError);
            toast.error('Account setup failed', {
              description: 'Unable to create your account. Please contact an administrator.',
            });
            await supabase.auth.signOut();
            navigate('/');
            return;
          }

          profile = createdProfile;
          toast.success('Welcome to Maestro!', {
            description: 'Your worker account has been created successfully.',
          });
        } else if (profileError) {
          // Other errors (not "not found")
          throw profileError;
        }

        // Check if user is suspended
        if (profile?.suspended) {
          toast.error('Account suspended', {
            description: 'Your account has been suspended. Please contact an administrator.',
          });
          await supabase.auth.signOut();
          navigate('/');
          return;
        }

        // Update last sign-in timestamp
        try {
          await supabase
            .from('profiles')
            .update({ last_sign_in_at: new Date().toISOString() })
            .eq('id', session.user.id);
        } catch (error) {
          console.error('Failed to mark last sign-in:', error);
        }

        // Navigate to appropriate dashboard based on role
        const isManager = profile.role === 'manager' || profile.role === 'root';

        // Only show success message for returning users (new users already got a message)
        if (profileError?.code !== 'PGRST116') {
          toast.success('Welcome back!', {
            description: 'You have been successfully signed in with Google.',
          });
        }

        navigate(isManager ? '/m/dashboard' : '/w/dashboard');
      } catch (err: any) {
        console.error('OAuth callback error:', err);
        setError(err.message || 'An error occurred during sign in');
        toast.error('Sign in failed', {
          description: err.message || 'An error occurred during sign in',
        });

        // Redirect to landing page after a short delay
        setTimeout(() => {
          navigate('/');
        }, 2000);
      }
    };

    handleOAuthCallback();
  }, [navigate]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
        <div className="w-full max-w-md space-y-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10 text-destructive mx-auto">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="h-6 w-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-semibold">Sign in failed</h1>
          <p className="text-sm text-muted-foreground">{error}</p>
          <p className="text-xs text-muted-foreground">Redirecting to sign in page...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-4 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
        <h1 className="text-2xl font-semibold">Completing sign in...</h1>
        <p className="text-sm text-muted-foreground">Please wait while we set up your session.</p>
      </div>
    </div>
  );
};

export default AuthCallback;
