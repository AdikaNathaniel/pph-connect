import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, BarChart, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useWorkerAnalytics } from '@/hooks/use-worker-analytics';
import {
  WorkerAnalyticsSummaryCard,
  WorkerAnalyticsDailyChart,
  WorkerAnalyticsDailyTable,
} from '@/components/worker';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import VersionTracker from '@/components/VersionTracker';
import { configureWorkerLogger, installWorkerLogger, logWorkerEvent } from '@/lib/workerLogger';

const WorkerAnalytics = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data, loading, error, refresh } = useWorkerAnalytics(user?.id);

  useEffect(() => {
    console.log('Worker analytics page mounted', {
      userId: user?.id,
      userRole: user?.role,
    });
    installWorkerLogger();
    if (user?.id) {
      configureWorkerLogger({ workerId: user.id });
    }
  }, [user]);

  // Release any current task when entering analytics
  useEffect(() => {
    const releaseCurrentTask = async () => {
      if (!user) return;

      try {
        // Use RPC function to release tasks
        const { data: releasedCount, error: releaseError } = await supabase
          .rpc('release_worker_tasks');

        if (releaseError) {
          console.error('Error releasing tasks:', releaseError);
          logWorkerEvent('warn', 'Failed to release tasks when entering analytics', 'analytics_release_tasks', {
            workerId: user.id,
            supabaseError: releaseError,
          });
        } else {
          console.log(`Released ${releasedCount} task(s) when entering analytics`);
        }
      } catch (error) {
        console.error('Unexpected error releasing tasks:', error);
        logWorkerEvent('error', 'Unexpected error releasing tasks', 'analytics_release_tasks', {
          workerId: user.id,
          error: error instanceof Error ? error.message : 'unknown error',
        }, error instanceof Error ? error.stack : undefined);
      }
    };

    releaseCurrentTask();
  }, [user]);

  const renderContent = () => {
    if (loading) {
      return (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <p className="text-muted-foreground">Loading analytics...</p>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (error) {
      return (
        <Card>
          <CardContent className="p-12 text-center space-y-4">
            <p className="text-destructive">{error}</p>
            <Button onClick={refresh}>Retry</Button>
          </CardContent>
        </Card>
      );
    }

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Worker Analytics</h1>
          <p className="text-muted-foreground">Track your performance and productivity</p>
        </div>

        <WorkerAnalyticsSummaryCard summary={data?.summary ?? null} />
        <WorkerAnalyticsDailyChart data={data?.dailyActivity ?? []} />
        <WorkerAnalyticsDailyTable dailyActivity={data?.dailyActivity ?? []} />

        <div className="text-right">
          <Button variant="ghost" onClick={refresh}>
            Refresh analytics
          </Button>
        </div>
      </div>
    );
  };

  return (
    <TooltipProvider>
      <div className="bg-background">
        <div className="flex flex-col h-screen overflow-hidden mx-auto max-w-[1568px] border-x">
          {/* Subtle Header */}
          <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0">
            <div className="flex h-12 items-center justify-between px-6">
              <div className="font-semibold text-sm">Maestro</div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Worker Analytics</span>
              </div>
              <div></div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto px-6 py-6">
            {renderContent()}
          </main>

          {/* Footer */}
          <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0">
            <div className="flex h-12 items-center justify-between px-6">
              <div className="flex items-center gap-2">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => navigate('/w/dashboard')}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </div>
              <div></div>
              <div className="flex items-center gap-4">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="opacity-50 cursor-not-allowed"
                    >
                      <BarChart className="h-4 w-4 mr-2" />
                      Analytics
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>You are already on the Analytics page</p>
                  </TooltipContent>
                </Tooltip>
                <VersionTracker />
              </div>
            </div>
          </footer>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default WorkerAnalytics;
