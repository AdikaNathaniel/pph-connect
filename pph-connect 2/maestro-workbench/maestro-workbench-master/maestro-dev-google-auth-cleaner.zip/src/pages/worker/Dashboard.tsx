import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle, Clock, Home, BarChart, LogOut, BookOpen, Mail } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { supabase } from '@/integrations/supabase/client';
import { Project, ProjectAssignment } from '@/types';
import type { Database } from '@/integrations/supabase/types';
import { toast } from "sonner";
import VersionTracker from '@/components/VersionTracker';
import { TrainingModal } from '@/components/worker';
import { configureWorkerLogger, installWorkerLogger, logWorkerEvent } from '@/lib/workerLogger';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { selectNextProject, SelectedProjectDetails } from '@/lib/projectSelection';
import { useMessageNotifications } from '@/hooks/useMessageNotifications';

type TrainingModuleRow = Database['public']['Tables']['training_modules']['Row'];

// Utility function to get the correct modifier key symbol based on OS
const getModifierKey = () => {
  if (typeof window === 'undefined') return '⌘'; // Default to Cmd for SSR
  return navigator.platform.toLowerCase().includes('mac') ? '⌘' : 'Ctrl';
};

// Utility function to render keyboard shortcut
const renderKeyboardShortcut = () => {
  const modifierKey = getModifierKey();
  return (
    <div className="ml-2 text-xs text-muted-foreground flex items-center">
      <kbd className="px-1.5 py-0.5 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded">{modifierKey}</kbd>
      <span className="mx-1">+</span>
      <kbd className="px-1.5 py-0.5 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded">Enter</kbd>
    </div>
  );
};

const releaseTaskReservation = async (taskId: string) => {
  const { data, error } = await supabase
    .rpc('release_task_by_id', { p_task_id: taskId });
  
  if (error) throw error;
  if (!data) {
    throw new Error('Task not found or already released');
  }
};

const WorkerDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { unreadCount } = useMessageNotifications();
  const [assignments, setAssignments] = useState<ProjectAssignment[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectState, setActiveProjectState] = useState<Project | null>(null);
  const [availableCount, setAvailableCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [trainingModule, setTrainingModule] = useState<TrainingModuleRow | null>(null);
  const [trainingCompletionId, setTrainingCompletionId] = useState<string | null>(null);
  const [trainingModalOpen, setTrainingModalOpen] = useState(false);
  const [completedTasksCount, setCompletedTasksCount] = useState<number>(0);
  const [selectionDetails, setSelectionDetails] = useState<SelectedProjectDetails | null>(null);
  const [projectTaskCounts, setProjectTaskCounts] = useState<Record<string, number>>({});

  const fetchWorkerData = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      configureWorkerLogger({ workerId: user.id });
      
      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from('project_assignments')
        .select('*')
        .eq('worker_id', user.id)
        .order('priority', { ascending: true });

      if (assignmentsError) throw assignmentsError;

      const projectIds = assignmentsData?.map(a => a.project_id) || [];
      const { data: projectsData, error: projectsError } = await supabase
        .from('projects')
        .select('*')
        .in('id', projectIds);

      if (projectsError) throw projectsError;

      let completedCount = 0;
      let selection: SelectedProjectDetails | null = null;

      if (projectIds.length > 0) {
        const { data: myTasks, error: tasksError } = await supabase
          .from('tasks')
          .select('status')
          .eq('assigned_to', user.id)
          .in('project_id', projectIds);

        if (tasksError) {
          console.warn('Dashboard fetch: failed to load worker tasks', tasksError);
          logWorkerEvent('warn', 'Failed to load worker tasks on dashboard', 'dashboard_fetch', {
            workerId: user.id,
            supabaseError: tasksError,
          });
        } else {
          completedCount = (myTasks ?? []).filter(task => task.status === 'completed').length;
        }

        selection = await selectNextProject({
          supabase,
          workerId: user.id,
          assignments: assignmentsData || [],
          projects: (projectsData || []) as Project[],
        });
      }

      // Calculate available task count per project
      const taskCounts: Record<string, number> = {};
      for (const project of (projectsData || [])) {
        const { data: countData, error: countError } = await supabase
          .rpc('count_claimable_questions', { p_project_id: project.id });

        if (countError) {
          console.warn('Dashboard fetch: failed to count claimable questions', project.id, countError);
          logWorkerEvent('warn', 'Failed to count claimable questions on dashboard', 'dashboard_fetch_count', {
            workerId: user.id,
            projectId: project.id,
            supabaseError: countError,
          });
          taskCounts[project.id] = 0;
        } else {
          taskCounts[project.id] = Number(countData ?? 0);
        }
      }

      setAssignments(assignmentsData || []);
      setProjects((projectsData || []) as Project[]);
      setCompletedTasksCount(completedCount);
      setActiveProjectState(selection?.project || null);
      setAvailableCount(selection?.availableCount || 0);
      setTrainingModule(selection?.trainingModule || null);
      setTrainingCompletionId(selection?.trainingCompletionId || null);
      setSelectionDetails(selection);
      setProjectTaskCounts(taskCounts);
    } catch (error) {
      console.error('Error fetching worker data:', error);
      logWorkerEvent('error', 'Error fetching worker dashboard data', 'dashboard_fetch', {
        workerId: user?.id,
        error: error instanceof Error ? error.message : 'unknown error',
      }, error instanceof Error ? error.stack : undefined);
      toast.error('Failed to load your assignments');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      installWorkerLogger();
      configureWorkerLogger({ workerId: user.id });
      fetchWorkerData();
    }
  }, [user, fetchWorkerData]);

  const handleLaunchWorkbench = useCallback(() => {
    navigate('/w/workbench');
  }, [navigate]);

  const hasNextTask = availableCount > 0;

  // Add Ctrl+Enter hotkey for Launch Tasks button
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
        event.preventDefault();
        if (hasNextTask) {
          handleLaunchWorkbench();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [hasNextTask, handleLaunchWorkbench]);

  const hasTraining = useMemo(() => Boolean(trainingModule), [trainingModule]);
  const isTrainingRequired = useMemo(() => Boolean(selectionDetails?.trainingRequired), [selectionDetails?.trainingRequired]);
  const isTrainingCompleted = useMemo(() => Boolean(selectionDetails?.trainingCompleted), [selectionDetails?.trainingCompleted]);
  const requiresTrainingCompletion = hasTraining && isTrainingRequired && !isTrainingCompleted;

  return (
    <TooltipProvider>
      <div className="bg-background">
        <div className="flex flex-col h-screen overflow-hidden mx-auto max-w-[1568px] border-x">
          {/* Subtle Header */}
          <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0">
            <div className="flex h-12 items-center justify-between px-6">
              {/* Left: Maestro */}
              <div className="font-semibold text-sm">Maestro</div>
              
              {/* Center: Empty for now, as no active task for dashboard */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Worker Dashboard</span>
              </div>
              
              {/* Right: Empty for now */}{" "}
              {/* You could add a Profile/Settings link here if needed */}
              <div></div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto px-6 py-6">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
              </div>
            ) : (!assignments || assignments.length === 0) ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">No assignments available</h3>
                    <p className="text-muted-foreground">
                      You haven't been assigned to any projects yet.
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : !activeProjectState ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <h3 className="text-xl font-semibold mb-2">All tasks completed</h3>
                  <p className="text-muted-foreground mb-4">
                    You've completed all available tasks in your assigned projects.
                  </p>
                  <div className="mt-6 space-y-3 max-w-md mx-auto">
                    <p className="text-sm font-medium text-left">Your assigned projects:</p>
                    {projects.map(project => (
                      <div key={project.id} className="flex items-center justify-between p-3 bg-muted rounded-md">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${
                            project.status === 'active' ? 'bg-green-500' : 'bg-yellow-500'
                          }`}></span>
                          <span className="text-sm">{project.name}</span>
                        </div>
                        <Badge variant="secondary">
                          {projectTaskCounts[project.id] ?? 0} available
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mt-6">
                    Contact your manager if you need additional assignments.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h1 className="text-3xl font-bold">Worker Dashboard</h1>
                    <p className="text-muted-foreground">Welcome back, {user?.full_name}</p>
                  </div>
                  {hasTraining && (
                    <div className="flex items-center gap-2">
                      <Badge variant={isTrainingCompleted ? 'default' : 'outline'}>
                        {isTrainingCompleted ? 'Training Complete' : 'Training Required'}
                      </Badge>
                      <Button
                        variant={requiresTrainingCompletion ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTrainingModalOpen(true)}
                      >
                        <BookOpen className="h-4 w-4 mr-2" />
                        Training
                      </Button>
                    </div>
                  )}
                </div>

                {/* Dashboard Content - 3 Cards */}
                <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center">
                        <CheckCircle className="h-8 w-8 text-success" />
                        <div className="ml-4">
                          <p className="text-sm font-medium text-muted-foreground">Completed in this session</p>
                          <p className="text-2xl font-bold">{completedTasksCount}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center">
                        <AlertCircle className="h-8 w-8 text-primary" />
                        <div className="ml-4">
                          <p className="text-sm font-medium text-muted-foreground">Available Tasks</p>
                          <p className="text-2xl font-bold">{availableCount}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center">
                        <Clock className="h-8 w-8 text-info" />
                        <div className="ml-4">
                          <p className="text-sm font-medium text-muted-foreground">Active Projects</p>
                          <p className="text-2xl font-bold">{assignments.length}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Launch Section */}
                <Card>
                  <CardContent className="p-12 text-center">
                    {requiresTrainingCompletion ? (
                      <div className="space-y-4">
                        <Alert variant="default" className="mx-auto max-w-xl text-left">
                          <AlertTitle className="flex items-center gap-2 text-base">
                            <AlertCircle className="h-4 w-4" />
                            Complete required training
                          </AlertTitle>
                          <AlertDescription className="mt-1 text-sm text-muted-foreground">
                            Please complete the training module before launching tasks for this project.
                          </AlertDescription>
                        </Alert>
                        <div className="flex justify-center">
                          <Button size="lg" onClick={() => setTrainingModalOpen(true)}>
                            <BookOpen className="h-4 w-4 mr-2" />
                            Review Training
                          </Button>
                        </div>
                      </div>
                    ) : hasNextTask ? (
                      <div>
                        <h3 className="text-xl font-semibold mb-2">Ready for next question?</h3>
                        <p className="text-muted-foreground mb-6">
                          You have {availableCount} questions available
                        </p>
                        <div className="flex justify-center items-center">
                          <Button onClick={handleLaunchWorkbench} size="lg">
                            Launch Tasks
                          </Button>
                          <Button
                            variant="outline"
                            size="lg"
                            className="ml-2"
                            onClick={async () => {
                              if (!selectionDetails?.project) {
                                toast.info('No project selected');
                                return;
                              }

                              console.log('Release & Refresh button clicked');
                              
                              const { data: tasks, error } = await supabase
                                .from('tasks')
                                .select('id, question_id, status, assigned_to, assigned_at')
                                .eq('assigned_to', user?.id)
                                .eq('project_id', selectionDetails.project.id)
                                .eq('status', 'assigned')
                                .limit(1);

                              if (error) {
                                console.error('Failed to check reservations', error);
                                toast.error('Failed to check reservations');
                                return;
                              }

                              console.log('Found tasks to release:', tasks);

                              if (!tasks?.length) {
                                console.log('No active reservations found');
                                toast.info('No active reservations to release');
                                return;
                              }

                              try {
                                console.log('Releasing task:', tasks[0].id);
                                await releaseTaskReservation(tasks[0].id);
                                console.log('Task released successfully from dashboard');
                                toast.success('Reservation released');
                                await fetchWorkerData();
                              } catch (releaseError) {
                                console.error('Failed to release reservation from dashboard', releaseError);
                                logWorkerEvent('error', 'Failed to release reservation from dashboard', 'release_reservation', {
                                  taskId: tasks[0].id,
                                  error: releaseError instanceof Error ? releaseError.message : String(releaseError)
                                });
                                toast.error('Failed to release reservation');
                              }
                            }}
                          >
                            Release & Refresh
                          </Button>
                          {renderKeyboardShortcut()}
                        </div>
                      </div>
                    ) : (
                      <div>
                        <h3 className="text-xl font-semibold mb-2">No questions available</h3>
                        <p className="text-muted-foreground">
                          All tasks in your assigned projects are currently completed or in progress.
                          Check back soon for new tasks.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </main>

          {/* Footer */}
          <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shrink-0">
            <div className="flex h-12 items-center justify-between px-6">
              {/* Left: Analytics & Messages */}
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/w/analytics')}
                >
                  <BarChart className="h-4 w-4 mr-2" />
                  Analytics
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/w/messages/inbox')}
                  className="relative"
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Messages
                  {unreadCount > 0 && (
                    <Badge variant="destructive" className="ml-2 h-5 px-1.5 text-xs">
                      {unreadCount}
                    </Badge>
                  )}
                </Button>
              </div>

              {/* Center: Empty for dashboard */}
              <div></div>

              {/* Right: Logout & Version */}
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={logout}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
                <div className="ml-2">
                  <VersionTracker />
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>

      {trainingModule && activeProjectState && user && selectionDetails && (
        <TrainingModal
          training={trainingModule}
          projectId={activeProjectState.id}
          workerId={user.id}
          isRequired={Boolean(selectionDetails.trainingRequired)}
          open={trainingModalOpen}
          onOpenChange={setTrainingModalOpen}
          onComplete={fetchWorkerData}
          isCompleted={Boolean(selectionDetails.trainingCompleted)}
        />
      )}
    </TooltipProvider>
  );
};

export default WorkerDashboard;
