import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Plus, Trash2, Copy, Save, Eye, EyeOff, Info } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { supabase } from '@/integrations/supabase/client';
import { ColumnConfig, TaskTemplate, Modality, ModalityConfig, LabelOntology } from '@/types';
import { toast } from "sonner";
import { useNavigate, useParams } from 'react-router-dom';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface SheetData {
  headers: string[];
  sampleRow: Record<string, any>;
}

interface TemplateFormData {
  name: string;
  description: string;
  google_sheet_url: string;
  modality: Modality;
  modality_config: ModalityConfig;
  label_ontology?: LabelOntology | null;
}

const getColumnLetter = (index: number): string => {
  let letter = '';
  let num = index;
  while (num >= 0) {
    letter = String.fromCharCode((num % 26) + 65) + letter;
    num = Math.floor(num / 26) - 1;
  }
  return letter;
};

const NewPlugin = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;
  
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [sheetData, setSheetData] = useState<SheetData | null>(null);
  const [columnConfigs, setColumnConfigs] = useState<ColumnConfig[]>([]);
  const [formData, setFormData] = useState<TemplateFormData>({
    name: '',
    description: '',
    google_sheet_url: '',
    modality: 'spreadsheet', // Default to spreadsheet for backward compatibility
    modality_config: {},
    label_ontology: null
  });

  useEffect(() => {
    if (isEdit) {
      fetchTemplate();
    }
  }, [id, isEdit]);

  const fetchTemplate = async () => {
    if (!id) return;
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('task_templates')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      setFormData({
        name: data.name,
        description: data.description || '',
        google_sheet_url: data.google_sheet_url,
        modality: data.modality || 'spreadsheet',
        modality_config: (data.modality_config as ModalityConfig) || {},
        label_ontology: (data.label_ontology as LabelOntology) || null
      });
      
      const savedConfigs = (data.column_config as unknown as ColumnConfig[]) || [];
      setColumnConfigs(savedConfigs);
      
      // Auto-load sheet data to enable editing
      if (data.google_sheet_url && savedConfigs.length > 0) {
        await loadSheetDataForEdit(data.google_sheet_url, savedConfigs);
      }
    } catch (error: any) {
      console.error('Error fetching template:', error);
      toast.error("Failed to load plugin");
    } finally {
      setLoading(false);
    }
  };

  const loadSheetDataForEdit = async (sheetUrl: string, savedConfigs: ColumnConfig[]) => {
    try {
      console.log('Loading sheet data for edit:', sheetUrl);
      const { data, error } = await supabase.functions.invoke('load-sheet-data', {
        body: { sheetUrl }
      });

      console.log('load-sheet-data for edit response:', { data, error });
      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Failed to load sheet data');
      }
      
      setSheetData({
        headers: data.headers,
        sampleRow: data.sampleRow
      });
    } catch (error: any) {
      console.error('Error loading sheet for edit:', error);
      toast("Could not load sheet data preview. You can still edit the plugin configuration.");
    }
  };

  const handleInputChange = (field: keyof TemplateFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLoadSheet = async () => {
    if (!formData.google_sheet_url) {
      toast.error("Please enter a Google Sheet URL first");
      return;
    }

    setLoadingSheet(true);
    try {
      console.log('Sending sheet URL to load-sheet-data:', formData.google_sheet_url);
      const { data, error } = await supabase.functions.invoke('load-sheet-data', {
        body: { sheetUrl: formData.google_sheet_url }
      });

      console.log('load-sheet-data response:', { data, error });
      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Failed to load sheet data');
      }
      
      const sheetData: SheetData = {
        headers: data.headers,
        sampleRow: data.sampleRow
      };
      
      // Only reset configs if we don't have any (new plugin)
      // Otherwise preserve existing configs when reloading sheet
      if (columnConfigs.length === 0) {
        const initialConfigs: ColumnConfig[] = data.headers.map((header: string, index: number) => ({
          id: `col-${index}`,
          name: header,
          columnLetter: getColumnLetter(index),
          type: 'read',
          hidden: false,
          inputType: 'text',
          required: false
        }));
        setColumnConfigs(initialConfigs);
      }
      
      setSheetData(sheetData);
      
      toast.success(`Loaded ${data.headers.length} columns from sheet`);
    } catch (error: any) {
      console.error('Error loading sheet:', error);
      toast.error(error.message || "Failed to load sheet data. Make sure the sheet is publicly accessible or shared with the service account.");
    } finally {
      setLoadingSheet(false);
    }
  };

  const copyServiceAccountEmail = async () => {
    const serviceAccountEmail = 'data-ops-workbench-service-acc@data-ops-workbenches.iam.gserviceaccount.com';
    try {
      await navigator.clipboard.writeText(serviceAccountEmail);
      toast.success('Service account email copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy email to clipboard');
    }
  };

  const updateColumnConfig = (index: number, field: keyof ColumnConfig, value: any) => {
    setColumnConfigs(prev => prev.map((config, i) => 
      i === index ? { ...config, [field]: value } : config
    ));
  };

  const addOption = (columnIndex: number) => {
    setColumnConfigs(prev => prev.map((config, i) => 
      i === columnIndex 
        ? { ...config, options: [...(config.options || []), ''] }
        : config
    ));
  };

  const updateOption = (columnIndex: number, optionIndex: number, value: string) => {
    setColumnConfigs(prev => prev.map((config, i) => 
      i === columnIndex 
        ? { 
            ...config, 
            options: (config.options || []).map((opt, j) => j === optionIndex ? value : opt)
          }
        : config
    ));
  };

  const updateOptionColor = (columnIndex: number, option: string, color: string) => {
    setColumnConfigs(prev => prev.map((config, i) => 
      i === columnIndex 
        ? { 
            ...config, 
            optionColors: { ...(config.optionColors || {}), [option]: color }
          }
        : config
    ));
  };

  const removeOption = (columnIndex: number, optionIndex: number) => {
    setColumnConfigs(prev => prev.map((config, i) => 
      i === columnIndex 
        ? { 
            ...config, 
            options: (config.options || []).filter((_, j) => j !== optionIndex)
          }
        : config
    ));
  };

  const handleSaveTemplate = async () => {
    // For audio-short modality, we don't need column configs or sheet URL
    const needsColumns = formData.modality !== 'audio-short';
    const needsSheetUrl = formData.modality !== 'audio-short';
    
    if (!formData.name || (needsSheetUrl && !formData.google_sheet_url) || (needsColumns && columnConfigs.length === 0)) {
      toast.error("Please fill in all required fields" + (needsColumns ? " and configure columns" : ""));
      return;
    }

    setSaving(true);
    try {
      // For audio-short, create a simple transcription column config
      const audioShortConfig = formData.modality === 'audio-short' ? [{
        id: 'audio_file',
        name: 'Audio File',
        type: 'read' as const,
        inputType: 'text' as const,
        required: false,
        pasteDetection: false
      }, {
        id: 'transcription',
        name: 'Transcription',
        type: 'write' as const,
        inputType: 'textarea' as const,
        required: true,
        pasteDetection: false
      }] : columnConfigs;

      const templateData = {
        name: formData.name,
        description: formData.description,
        google_sheet_url: formData.google_sheet_url || '', // Empty for audio-short, will be set at project creation
        column_config: audioShortConfig as any,
        modality: formData.modality,
        modality_config: formData.modality === 'audio-short' ? {
          'audio-short': {
            fileFormats: ['mp3', 'wav', 'ogg', 'm4a', 'aac'],
            quality: 'high' as const,
            storageUrl: '', // Will be set at project creation
            transcriptionRequired: true,
            playbackControls: {
              speed: false,
              loop: false,
              rewind: false
            }
          }
        } : formData.modality_config,
        label_ontology: formData.label_ontology
      };

      let result;
      if (isEdit) {
        const { data, error } = await supabase
          .from('task_templates')
          .update(templateData)
          .eq('id', id)
          .select()
          .single();
        result = { data, error };
      } else {
        const { data, error } = await supabase
          .from('task_templates')
          .insert([{
            ...templateData,
            created_by: (await supabase.auth.getUser()).data.user?.id
          }])
          .select()
          .single();
        result = { data, error };
      }

      if (result.error) throw result.error;

      toast.success(`Plugin "${formData.name}" ${isEdit ? 'updated' : 'created'} successfully!`);

      navigate('/m/plugins');
    } catch (error: any) {
      console.error('Error saving template:', error);
      toast.error(error.message || "Failed to save plugin");
    } finally {
      setSaving(false);
    }
  };

  const renderColumnConfig = (config: ColumnConfig, index: number) => (
    <Card key={config.id} className="mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Badge variant="outline">{config.columnLetter}</Badge>
            <h4 className="font-medium">{config.name}</h4>
            <Badge variant={config.type === 'read' ? 'secondary' : 'default'}>
              {config.type}
            </Badge>
            {config.hidden && (
              <Badge variant="outline" className="gap-1">
                <EyeOff className="h-3 w-3" />
                Hidden
              </Badge>
            )}
          </div>
        </div>

        {sheetData && (
          <div className="mb-4 p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium mb-1">Sample Data:</div>
            <div className="text-sm text-muted-foreground">
              {sheetData.sampleRow[config.name] || 'No sample data'}
            </div>
          </div>
        )}

        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              checked={config.hidden || false}
              onCheckedChange={(checked) => 
                updateColumnConfig(index, 'hidden', checked)
              }
            />
            <Label>Hide this column (won't be displayed in workbench)</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              checked={config.type === 'write'}
              onCheckedChange={(checked) => 
                updateColumnConfig(index, 'type', checked ? 'write' : 'read')
              }
            />
            <Label>Make this field writeable (workers can input data)</Label>
          </div>

          {config.type === 'write' && (
            <>
              <div>
                <Label>Input Type</Label>
                <Select 
                  value={config.inputType || 'text'} 
                  onValueChange={(value) => updateColumnConfig(index, 'inputType', value as any)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">Text Input</SelectItem>
                    <SelectItem value="textarea">Text Area</SelectItem>
                    <SelectItem value="select">Dropdown Selection</SelectItem>
                    <SelectItem value="radio">Radio Buttons</SelectItem>
                    <SelectItem value="rating">Star Rating</SelectItem>
                    <SelectItem value="number">Number Input</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.required || false}
                  onCheckedChange={(checked) => updateColumnConfig(index, 'required', checked)}
                />
                <Label>Required field</Label>
              </div>

              <div className="space-y-2">
                <Label>Field Tooltip (optional)</Label>
                <Textarea
                  value={config.tooltip || ''}
                  onChange={(e) => updateColumnConfig(index, 'tooltip', e.target.value)}
                  placeholder="Add helpful instructions that will appear on hover... (Markdown supported)"
                  className="min-h-[60px]"
                />
                <p className="text-xs text-muted-foreground">
                  If provided, a tooltip icon will appear next to this field with these instructions. 
                  <strong> Markdown supported:</strong> Use **bold**, *italic*, `code`, lists, etc.
                </p>
                {config.tooltip && (
                  <div className="mt-2 p-3 bg-muted rounded-md border">
                    <p className="text-xs text-muted-foreground mb-2">Preview:</p>
                    <div className="text-sm prose prose-sm max-w-none">
                      <ReactMarkdown>{config.tooltip}</ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>

              {(config.inputType === 'text' || config.inputType === 'textarea') && (
                <>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={config.pasteDetection || false}
                      onCheckedChange={(checked) => updateColumnConfig(index, 'pasteDetection', checked)}
                    />
                    <Label>Log paste events for this field</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={config.pastePreventionEnabled || false}
                      onCheckedChange={(checked) => updateColumnConfig(index, 'pastePreventionEnabled', checked)}
                    />
                    <Label>Prevent paste in this field</Label>
                  </div>
                </>
              )}

              <div className="border-t pt-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Switch
                    checked={!!config.conditional}
                    onCheckedChange={(checked) => 
                      updateColumnConfig(index, 'conditional', checked ? {
                        dependsOnColumn: '',
                        requiredValue: ''
                      } : undefined)
                    }
                  />
                  <Label>Conditional (only shown and required if another column has specific value)</Label>
                </div>
                
                {config.conditional && (
                  <div className="ml-8 space-y-2 p-3 bg-blue-50 rounded-md border">
                    <p className="text-xs text-blue-700 mb-2">
                      This field will only be shown and required when the selected column has the specified value.
                      <br />
                      <strong>Example:</strong> Set "Answer Relevance" to depend on "Article Support" = "Supported"
                    </p>
                    <div>
                      <Label className="text-sm">Depends on column</Label>
                      <Select 
                        value={config.conditional.dependsOnColumn} 
                        onValueChange={(value) => 
                          updateColumnConfig(index, 'conditional', {
                            ...config.conditional!,
                            dependsOnColumn: value
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select column" />
                        </SelectTrigger>
                        <SelectContent>
                          {columnConfigs
                            .filter((c, i) => i !== index && c.type === 'write' && (c.inputType === 'select' || c.inputType === 'radio'))
                            .map((c) => (
                              <SelectItem key={c.id} value={c.name}>
                                {c.columnLetter} - {c.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {config.conditional.dependsOnColumn && (
                      <div>
                        <Label className="text-sm">Required value</Label>
                        <Select 
                          value={config.conditional.requiredValue} 
                          onValueChange={(value) => 
                            updateColumnConfig(index, 'conditional', {
                              ...config.conditional!,
                              requiredValue: value
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select required value" />
                          </SelectTrigger>
                          <SelectContent>
                            {columnConfigs
                              .find(c => c.name === config.conditional!.dependsOnColumn)
                              ?.options?.map((opt) => (
                                <SelectItem key={opt} value={opt}>
                                  {opt}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {(config.inputType === 'select' || config.inputType === 'radio') && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Options</Label>
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => addOption(index)}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Option
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {(config.options || []).map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center space-x-2">
                        <Input
                          value={option}
                          onChange={(e) => updateOption(index, optionIndex, e.target.value)}
                          placeholder="Enter option text"
                          className="flex-1"
                        />
                        <Input
                          type="color"
                          value={config.optionColors?.[option] || '#3b82f6'}
                          onChange={(e) => updateOptionColor(index, option, e.target.value)}
                          className="w-16 h-9 p-1 cursor-pointer"
                          title="Choose color for this option"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeOption(index, optionIndex)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => navigate('/m/plugins')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Plugins
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Plugin Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Plugin Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Enter plugin name"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Describe what this plugin is used for"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="modality">Task Modality *</Label>
            <Select
              value={formData.modality}
              onValueChange={(value) => handleInputChange('modality', value as Modality)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select task modality" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="spreadsheet">📊 Spreadsheet (Current)</SelectItem>
                <SelectItem value="audio-short">🎵 Audio Shortform (Playback + Form)</SelectItem>
                <SelectItem value="audio-long">🎧 Audio Longform (Waveform Annotation)</SelectItem>
                <SelectItem value="text">📝 Text Annotation</SelectItem>
                <SelectItem value="image">🖼️ Image Annotation</SelectItem>
                <SelectItem value="video">🎬 Video Annotation</SelectItem>
                <SelectItem value="multimodal">🔀 Multimodal Tasks</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground mt-1">
              Choose the type of tasks this plugin will handle. Spreadsheet is the current format.
            </p>
          </div>

          {formData.modality === 'audio-short' ? (
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                This plugin is configured for audio transcription tasks. When you create a project using this plugin, you'll provide a Google Drive folder URL containing the audio files.
              </p>
              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium">Plugin Configuration:</p>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
                  <li>Audio player with waveform visualization</li>
                  <li>Single transcription text field</li>
                  <li>Supports: MP3, WAV, M4A, AAC, OGG</li>
                </ul>
              </div>
            </div>
          ) : (
            <>
              <div>
                <Label htmlFor="sheet_url">Google Sheet URL *</Label>
                <Input
                  id="sheet_url"
                  value={formData.google_sheet_url}
                  onChange={(e) => handleInputChange('google_sheet_url', e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  required
                />
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Sheet Sharing Required</AlertTitle>
                <AlertDescription className="space-y-3">
                  <p>This sheet must be shared with our service account:</p>
                  <div className="flex items-center gap-2">
                    <code className="bg-muted px-2 py-1 rounded text-sm font-mono">
                      data-ops-workbench-service-acc@data-ops-workbenches.iam.gserviceaccount.com
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={copyServiceAccountEmail}
                      className="h-8 px-2"
                    >
                      <Copy className="h-3 w-3 mr-1" />
                      Copy Email
                    </Button>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium mb-1">How to share:</p>
                    <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                      <li>Open your Google Sheet</li>
                      <li>Click the "Share" button</li>
                      <li>Add the email above with "Viewer" access</li>
                      <li>Click "Share"</li>
                    </ol>
                  </div>
                </AlertDescription>
              </Alert>

              <Button 
                onClick={handleLoadSheet}
                disabled={loadingSheet || !formData.google_sheet_url}
              >
                {loadingSheet ? 'Loading...' : 'Load Sheet Structure'}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {sheetData && (
        <Card>
          <CardHeader>
            <CardTitle>Column Configuration</CardTitle>
            <p className="text-sm text-muted-foreground">
              Configure how each column from your sheet should be handled in the workbench.
              Read fields are displayed as cards, write fields allow worker input.
            </p>
          </CardHeader>
          <CardContent>
            {columnConfigs.map((config, index) => renderColumnConfig(config, index))}
          </CardContent>
        </Card>
      )}

      {(sheetData || formData.modality === 'audio-short') && (
        <div className="flex justify-between">
          <div className="flex gap-2">
            <Button variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              Preview Plugin
            </Button>
            {!isEdit && (
              <Button variant="outline">
                <Copy className="h-4 w-4 mr-2" />
                Duplicate Plugin
              </Button>
            )}
          </div>
          
          <Button onClick={handleSaveTemplate} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : `${isEdit ? 'Update' : 'Save'} Plugin`}
          </Button>
        </div>
      )}
    </div>
  );
};

export default NewPlugin;