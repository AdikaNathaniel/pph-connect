import React, { useEffect, useState } from 'react';
import { Users, PlaneTakeoff, Activity, CircleCheckBig } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { StatCard } from '@/components/patterns/stat-card';
import { AreaChartGradient } from '@/components/patterns/AreaChartGradient';
import { ProjectsOverviewTable } from '@/components/patterns/ProjectsOverviewTable';

interface DashboardData {
  totalProjects: number;
  activeProjects: number;
  totalWorkers: number;
  pendingQuestions: number;
  totalAnswers: number;
  dailyActivity: { date: string; answers: number }[];
}

const Dashboard: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch all counts in parallel
      const [
        projectsCount,
        activeProjectsCount,
        workersCount,
        pendingQuestionsCount,
        answersCount,
        answersData
      ] = await Promise.all([
        supabase.from('projects').select('*', { count: 'exact', head: true }),
        supabase.from('projects').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'worker'),
        supabase.from('questions').select('*', { count: 'exact', head: true }).eq('is_answered', false),
        supabase.from('answers').select('*', { count: 'exact', head: true }),
        // Get last 30 days of answers for the chart
        supabase
          .from('answers')
          .select('completion_time')
          .gte('completion_time', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
          .order('completion_time', { ascending: false })
      ]);

      // Aggregate daily activity
      const dailyMap = new Map<string, number>();
      if (answersData.data) {
        answersData.data.forEach((answer: any) => {
          const date = new Date(answer.completion_time).toISOString().slice(0, 10);
          dailyMap.set(date, (dailyMap.get(date) || 0) + 1);
        });
      }

      const dailyActivity = Array.from(dailyMap.entries())
        .map(([date, answers]) => ({ date, answers }))
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(-14); // Last 14 days

      setData({
        totalProjects: projectsCount.count || 0,
        activeProjects: activeProjectsCount.count || 0,
        totalWorkers: workersCount.count || 0,
        pendingQuestions: pendingQuestionsCount.count || 0,
        totalAnswers: answersCount.count || 0,
        dailyActivity
      });
    } catch (err: any) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const projectsInFlight = data?.activeProjects ?? 0;
  const totalWorkers = data?.totalWorkers ?? 0;
  const activeQuestions = data?.pendingQuestions ?? 0;
  const answersInserted = data?.totalAnswers ?? 0;
  const dailyActivity = data?.dailyActivity ?? [];

  const stats = [
    {
      title: 'Projects in Flight',
      value: projectsInFlight,
      icon: PlaneTakeoff,
      trend: {
        value: projectsInFlight > 0 ? `${projectsInFlight} active` : 'No active projects', 
        direction: 'up' as const,
      },
      summary: projectsInFlight > 0 ? `${projectsInFlight} project${projectsInFlight > 1 ? 's' : ''} currently running` : 'No active projects', 
      metaContext: 'Active project count',
    },
    {
      title: 'Total Workers',
      value: totalWorkers,
      icon: Users,
      trend: {
        value: totalWorkers > 0 ? `${totalWorkers} registered` : 'No workers yet', 
        direction: 'up' as const,
      },
      summary: totalWorkers > 0 ? `${totalWorkers} worker${totalWorkers > 1 ? 's' : ''} in workforce` : 'No workers registered', 
      metaContext: 'Registered active workers',
    },
    {
      title: 'Active Questions',
      value: activeQuestions,
      icon: Activity,
      trend: {
        value: activeQuestions > 0 ? `${activeQuestions} pending` : 'None pending', 
        direction: activeQuestions > 0 ? 'up' as const : 'down' as const,
      },
      summary: activeQuestions > 0 ? `${activeQuestions} question${activeQuestions > 1 ? 's' : ''} awaiting answers` : 'All questions answered', 
      metaContext: 'Questions pending review',
    },
    {
      title: 'Answers Inserted',
      value: answersInserted,
      icon: CircleCheckBig,
      trend: {
        value: answersInserted > 0 ? `${answersInserted} total` : 'No answers yet', 
        direction: 'up' as const,
      },
      summary: answersInserted > 0 ? `${answersInserted} answer${answersInserted > 1 ? 's' : ''} completed` : 'No answers submitted yet', 
      metaContext: 'Answers processed lifetime',
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center text-destructive">
          <p>{error}</p>
          <button onClick={fetchDashboardData} className="mt-4 text-primary underline">
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <StatCard
            key={stat.title}
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            trend={stat.trend}
            summary={stat.summary}
            metaContext={stat.metaContext}
          />
        ))}
      </div>

      {/* Daily Answers Chart */}
      <AreaChartGradient data={dailyActivity} />

      {/* Project Overview Table */}
      <ProjectsOverviewTable />
    </div>
  );
};

export default Dashboard;
