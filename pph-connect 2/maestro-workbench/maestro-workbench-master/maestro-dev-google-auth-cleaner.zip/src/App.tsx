import React from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useParams } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { SpeedInsights } from "@vercel/speed-insights/react";
import Header from "@/components/layout/Header";
import ManagerLayout from "@/components/layout/ManagerLayout";
import ProtectedRoute from "@/components/ProtectedRoute";
import Landing from "./pages/Landing";
import AdminSetup from "./pages/admin/Setup";
import ManagerDashboard from "./pages/manager/Dashboard";
import Projects from "./pages/manager/Projects";
import UserManagement from "./pages/manager/UserManagement";
import ProjectAssignment from "./pages/manager/ProjectAssignment";
import NewProject from "./pages/manager/NewProject";
import PluginManager from "./pages/manager/PluginManager";
import NewPlugin from "./pages/manager/NewPlugin";
import Stats from "./pages/manager/Stats";
import Questions from "./pages/manager/Questions";
import PasteLogs from "./pages/manager/PasteLogs";
import ClientLogs from "./pages/manager/ClientLogs";
import TrainingModules from "./pages/manager/TrainingModules";
import WorkerDashboard from "./pages/worker/Dashboard";
import WorkerWorkbench from "./pages/worker/Workbench";
import WorkerAnalytics from "./pages/worker/Analytics";
import MessagesInbox from "./pages/messages/Inbox";
import MessagesCompose from "./pages/messages/Compose";
import MessagesThread from "./pages/messages/Thread";
import MessagesBroadcast from "./pages/messages/Broadcast";
import GroupConversation from "./pages/messages/GroupConversation";
import GroupInfo from "./pages/messages/GroupInfo";
import NotFound from "./pages/NotFound";
import ChangePassword from "./pages/ChangePassword";
import TestDriveAccess from "./pages/TestDriveAccess";
import AuthCallback from "./pages/AuthCallback";

const queryClient = new QueryClient();

const PluginEditRedirect = () => {
  const { id } = useParams();
  return <Navigate to={`/m/plugins/edit/${id}`} replace />;
};

const TemplateEditRedirect = () => {
  const { id } = useParams();
  return <Navigate to={`/m/templates/edit/${id}`} replace />;
};

const AppRoutes = () => {
  const { isAuthenticated, user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  const isManager = user?.role === 'manager' || user?.role === 'root';
  const isWorker = user?.role === 'worker';

  return (
    <div className="min-h-screen bg-background">
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={
          isAuthenticated ? <Navigate to={isManager ? "/m/dashboard" : "/w/dashboard"} replace /> : <Landing />
        } />
        <Route path="/auth" element={
          isAuthenticated ? <Navigate to={isManager ? "/m/dashboard" : "/w/dashboard"} replace /> : <Landing />
        } />
        <Route path="/auth/callback" element={<AuthCallback />} />
        <Route path="/w" element={
          isAuthenticated ? <Navigate to="/w/dashboard" replace /> : <Navigate to="/?role=worker" replace />
        } />
        <Route path="/m" element={
          isAuthenticated ? <Navigate to="/m/dashboard" replace /> : <Navigate to="/?role=manager" replace />
        } />
        <Route path="/admin/setup" element={<AdminSetup />} />
        
        {/* Manager Routes (/m/*) */}
        <Route path="/m/dashboard" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Dashboard">
              <ManagerDashboard />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/projects" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Project Overview">
              <Projects />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/projects/new" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="New Project">
              <NewProject />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/projects/questions/:projectId" element={
          <ProtectedRoute requiredRole="manager">
            <>
              <Header />
              <main className="flex-1 overflow-y-auto px-6 py-6">
                <Questions />
              </main>
            </>
          </ProtectedRoute>
        } />
        <Route path="/m/users" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="User Management">
              <UserManagement />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/assignments" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Project Assignments">
              <ProjectAssignment />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/plugins" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Plugin Manager">
              <PluginManager />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/plugins/new" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="New Plugin">
              <NewPlugin />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/plugins/edit/:id" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Edit Plugin">
              <NewPlugin />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/templates" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Templates">
              <PluginManager />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/templates/new" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="New Template">
              <NewPlugin />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/templates/edit/:id" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Edit Template">
              <NewPlugin />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/analytics" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Analytics">
              <Stats />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/training-modules" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Training Modules">
              <TrainingModules />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/paste-logs" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Paste Logs">
              <PasteLogs />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/client-logs" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Client Logs">
              <ClientLogs />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/inbox" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Messages">
              <MessagesInbox />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/compose" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Compose Message">
              <MessagesCompose />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/thread/:threadId" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Message Thread">
              <MessagesThread />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/broadcast" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Broadcast Message">
              <MessagesBroadcast />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/group/:groupId" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Group Conversation">
              <GroupConversation />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/m/messages/group/:groupId/info" element={
          <ProtectedRoute requiredRole="manager">
            <ManagerLayout pageTitle="Group Info">
              <GroupInfo />
            </ManagerLayout>
          </ProtectedRoute>
        } />
        <Route path="/test-drive" element={
          <ProtectedRoute requiredRole="manager">
            <TestDriveAccess />
          </ProtectedRoute>
        } />

        {/* Worker Routes (/w/*) */}
        <Route path="/w/dashboard" element={
          <ProtectedRoute requiredRole="worker">
            <WorkerDashboard />
          </ProtectedRoute>
        } />
        <Route path="/w/workbench" element={
          <ProtectedRoute requiredRole="worker">
            <WorkerWorkbench />
          </ProtectedRoute>
        } />
        <Route path="/w/analytics" element={
          <ProtectedRoute requiredRole="worker">
            <WorkerAnalytics />
          </ProtectedRoute>
        } />
        <Route path="/w/messages/inbox" element={
          <ProtectedRoute requiredRole="worker">
            <>
              <Header />
              <main className="flex-1 overflow-y-auto px-6 py-6">
                <MessagesInbox />
              </main>
            </>
          </ProtectedRoute>
        } />
        <Route path="/w/messages/compose" element={
          <ProtectedRoute requiredRole="worker">
            <>
              <Header />
              <main className="flex-1 overflow-y-auto px-6 py-6">
                <MessagesCompose />
              </main>
            </>
          </ProtectedRoute>
        } />
        <Route path="/w/messages/group/:groupId" element={
          <ProtectedRoute requiredRole="worker">
            <>
              <Header />
              <div className="container mx-auto py-6">
                <GroupConversation />
              </div>
            </>
          </ProtectedRoute>
        } />
        <Route path="/w/messages/group/:groupId/info" element={
          <ProtectedRoute requiredRole="worker">
            <>
              <Header />
              <div className="container mx-auto py-6">
                <GroupInfo />
              </div>
            </>
          </ProtectedRoute>
        } />
        <Route path="/w/messages/thread/:threadId" element={
          <ProtectedRoute requiredRole="worker">
            <>
              <Header />
              <main className="flex-1 overflow-y-auto px-6 py-6">
                <MessagesThread />
              </main>
            </>
          </ProtectedRoute>
        } />

        {/* Shared Routes */}
        <Route path="/change-password" element={
          <ProtectedRoute>
            <>
              <main className="flex-1 overflow-y-auto px-6 py-6">
                <ChangePassword />
              </main>
            </>
          </ProtectedRoute>
        } />

        {/* Legacy Redirects to prevent 404s */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            {isManager ? (
              <Navigate to="/m/dashboard" replace />
            ) : (
              <Navigate to="/w/dashboard" replace />
            )}
          </ProtectedRoute>
        } />
        <Route path="/manager" element={<Navigate to="/m/dashboard" replace />} />
        <Route path="/manager/users" element={<Navigate to="/m/users" replace />} />
        <Route path="/manager/assignments" element={<Navigate to="/m/assignments" replace />} />
        <Route path="/manager/paste-logs" element={<Navigate to="/m/paste-logs" replace />} />
        <Route path="/new-project" element={<Navigate to="/m/projects/new" replace />} />
        <Route path="/plugins" element={<Navigate to="/m/plugins" replace />} />
        <Route path="/plugins/new" element={<Navigate to="/m/plugins/new" replace />} />
        <Route path="/plugins/edit/:id" element={<PluginEditRedirect />} />
        <Route path="/templates" element={<Navigate to="/m/templates" replace />} />
        <Route path="/templates/new" element={<Navigate to="/m/templates/new" replace />} />
        <Route path="/templates/edit/:id" element={<TemplateEditRedirect />} />
        <Route path="/stats" element={<Navigate to="/m/analytics" replace />} />
        <Route path="/questions/:projectId" element={<Navigate to="/m/projects/questions/:projectId" replace />} />
        <Route path="/workbench" element={<Navigate to="/w/workbench" replace />} />
        <Route path="/analytics" element={
          <ProtectedRoute>
            {isManager ? (
              <Navigate to="/m/analytics" replace />
            ) : (
              <Navigate to="/w/analytics" replace />
            )}
          </ProtectedRoute>
        } />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
      <SpeedInsights />
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
