# Group Messaging Implementation Guide

## Summary of Changes

### ✅ Completed: Broadcast Attachments

**File Modified**: `src/pages/messages/Broadcast.tsx`

Added full attachment support to broadcast messages:
- File upload UI with drag-and-drop
- Preview and remove attachments
- Upload to Supabase storage (`attachments/message-attachments/`)
- Attachment metadata passed to edge function
- Maximum 5 attachments per broadcast
- Proper cleanup of file previews

**How to Test**:
1. Navigate to Messages → Broadcast
2. Click "Add Files" button
3. Select files (images, documents, etc.)
4. Files appear in list with size info
5. Remove files with X button if needed
6. Send broadcast - attachments are uploaded and delivered

---

## 🚧 In Progress: WhatsApp-Style Group Messaging

### Architecture Overview

The group messaging system has been redesigned to support true conversation groups (like WhatsApp) rather than just saved recipient lists.

### Database Schema Changes

#### Two New Migration Files Created

1. **`20251029210000_enhance_groups_for_conversations.sql`**
   - Enhances `message_groups` table with metadata
   - Creates `group_members` table for membership tracking
   - Adds `group_id` column to `messages` table
   - Auto-adds group creator as admin via trigger

2. **`20251029210001_groups_rls_policies.sql`**
   - RLS policies for viewing/managing groups
   - Policies for group membership
   - Policies for sending/viewing group messages

### Key Schema Components

#### Enhanced `message_groups` Table
```sql
- id (uuid, PK)
- name (text) -- Group name
- created_by (uuid) -- Creator user ID
- recipient_ids (uuid[]) -- Still used for 'saved_list' type
- description (text) -- NEW: Optional group description
- avatar_url (text) -- NEW: Optional group avatar
- is_active (boolean) -- NEW: Archive groups without deleting
- group_type (text) -- NEW: 'conversation' or 'saved_list'
- created_at, updated_at (timestamptz)
```

#### New `group_members` Table
```sql
- id (uuid, PK)
- group_id (uuid, FK to message_groups)
- user_id (uuid, FK to profiles)
- role (text) -- 'admin' or 'member'
- joined_at (timestamptz) -- When user joined
- left_at (timestamptz) -- NULL if active, timestamp if left
- created_at (timestamptz)
- UNIQUE(group_id, user_id)
```

#### Enhanced `messages` Table
```sql
- (existing columns...)
- group_id (uuid, FK) -- NEW: Links message to a group
```

### Group Types

1. **Conversation Groups** (`group_type = 'conversation'`)
   - WhatsApp-style persistent groups
   - Members tracked in `group_members` table
   - All members see all messages
   - Admins can add/remove members
   - Creator is automatically added as admin

2. **Saved Lists** (`group_type = 'saved_list'`)
   - Legacy saved recipient lists for broadcasts
   - Uses `recipient_ids` array
   - No membership tracking
   - Only visible to creator

### How Group Messages Work

1. **Sending to a Group**:
   - Message has `group_id` set (not individual `recipient_ids`)
   - Only group members can send
   - Message appears in group conversation for all members

2. **Viewing Group Messages**:
   - Users see messages from groups they're members of
   - RLS policies check `group_members` table
   - Messages ordered by `sent_at`

3. **Group Management**:
   - Creator and admins can add/remove members
   - Members can leave groups (sets `left_at` timestamp)
   - Inactive groups can be archived (`is_active = false`)

---

## 📋 Deployment Steps

### 1. Deploy Migrations

```bash
# Connect to your Supabase project
supabase link --project-ref your-project-ref

# Push the new migrations
supabase db push
```

**Migrations to Deploy**:
- `20251029210000_enhance_groups_for_conversations.sql`
- `20251029210001_groups_rls_policies.sql`

### 2. Verify Schema

After deployment, verify in Supabase Dashboard:

1. **Tables**:
   - Check `message_groups` has new columns: `description`, `avatar_url`, `is_active`, `group_type`
   - Check `group_members` table exists with proper indexes
   - Check `messages` table has `group_id` column

2. **Policies**:
   - Check RLS is enabled on `group_members`
   - Verify policies exist for viewing/managing groups
   - Test policies work correctly

---

## 🎨 UI Components Needed

### 1. Groups Tab in Inbox

**Location**: `src/pages/messages/Inbox.tsx`

**Requirements**:
- Add "Groups" tab alongside "All", "Unread", "Sent"
- Fetch groups where user is a member:
  ```sql
  SELECT mg.*, COUNT(DISTINCT m.id) as message_count
  FROM message_groups mg
  JOIN group_members gm ON gm.group_id = mg.id
  LEFT JOIN messages m ON m.group_id = mg.id
  WHERE gm.user_id = current_user_id
    AND gm.left_at IS NULL
    AND mg.group_type = 'conversation'
  GROUP BY mg.id
  ORDER BY mg.updated_at DESC
  ```
- Display list of groups with:
  - Group avatar (or default icon)
  - Group name
  - Member count
  - Last message preview
  - Unread indicator

### 2. Create Group Dialog

**Location**: New component `src/components/messages/CreateGroupDialog.tsx`

**Requirements**:
- Modal/dialog triggered from Inbox
- Form fields:
  - Group name (required)
  - Group description (optional)
  - Select members (checkboxes, similar to Broadcast)
- On submit:
  1. Create group in `message_groups` (type='conversation')
  2. Add selected members to `group_members`
  3. Creator automatically added as admin by trigger
  4. Navigate to group conversation

**Example Code**:
```typescript
const handleCreateGroup = async () => {
  const { data: group, error } = await supabase
    .from('message_groups')
    .insert({
      name: groupName,
      description: groupDescription,
      created_by: currentUser.id,
      group_type: 'conversation',
      is_active: true
    })
    .select()
    .single();

  if (error) throw error;

  // Add members
  const members = selectedUserIds.map(userId => ({
    group_id: group.id,
    user_id: userId,
    role: 'member'
  }));

  await supabase.from('group_members').insert(members);

  // Navigate to group
  navigate(`/messages/group/${group.id}`);
};
```

### 3. Group Conversation View

**Location**: New component `src/pages/messages/GroupConversation.tsx`

**Requirements**:
- Similar to Thread.tsx but for groups
- Header with:
  - Group avatar
  - Group name
  - Member count
  - Group info button (shows description, members list)
  - Leave group button
- Message list:
  - Fetch messages where `group_id = groupId`
  - Show sender name for each message (not just "You")
  - Support attachments
  - Realtime updates (optional)
- Reply/compose area:
  - Text input
  - Attachment support
  - Send button
  - On send: create message with `group_id`, no `recipient_ids`

**Example Query**:
```typescript
const { data: messages } = await supabase
  .from('messages')
  .select(`
    id,
    content,
    sent_at,
    sender_id,
    attachments,
    profiles!messages_sender_id_fkey(full_name, role)
  `)
  .eq('group_id', groupId)
  .is('deleted_at', null)
  .order('sent_at', { ascending: true });
```

### 4. Group Info/Management Page

**Location**: New component `src/pages/messages/GroupInfo.tsx`

**Requirements**:
- Display group details:
  - Name, description
  - Created by, created date
  - Avatar (with upload option for admins)
- Members list:
  - Show all members with roles
  - Admin badge for admins
  - Remove member button (admins only)
  - Leave group button (for self)
- Add members (admins only):
  - Button to open member selector
  - Search/filter users
  - Add selected users
- Edit group (admins only):
  - Edit name, description
  - Change avatar
  - Archive/activate group

### 5. Send Message to Group (Edge Function Update)

**Location**: `supabase/functions/send-message/index.ts`

**Changes Needed**:
- Accept optional `group_id` parameter
- If `group_id` provided:
  - Verify sender is group member
  - Create message with `group_id`
  - Don't create `message_recipients` records (members are implicit)
- If no `group_id`:
  - Use existing logic for direct messages

**Example**:
```typescript
// In send-message edge function
if (group_id) {
  // Verify membership
  const { data: membership } = await supabase
    .from('group_members')
    .select('id')
    .eq('group_id', group_id)
    .eq('user_id', user.id)
    .is('left_at', null)
    .single();

  if (!membership) {
    return error('Not a member of this group');
  }

  // Create message
  await supabase.from('messages').insert({
    group_id,
    sender_id: user.id,
    content,
    attachments
  });
} else {
  // Existing direct message logic
}
```

---

## 🧪 Testing Checklist

### Broadcast Attachments
- [ ] Add files to broadcast
- [ ] Remove files before sending
- [ ] Send broadcast with attachments
- [ ] Recipients receive attachments
- [ ] Attachments are downloadable

### Groups (After UI Implementation)
- [ ] Create new group
- [ ] Creator is auto-added as admin
- [ ] Add members to group
- [ ] Send message to group
- [ ] All members see message
- [ ] Leave group
- [ ] Admin removes member
- [ ] Edit group details
- [ ] Archive group
- [ ] View group in Groups tab

---

## 📊 Current Status

| Feature | Status | Notes |
|---------|--------|-------|
| Broadcast Attachments | ✅ Complete | Fully functional |
| Database Schema | ✅ Complete | Migrations created |
| RLS Policies | ✅ Complete | Security implemented |
| Groups Tab UI | ⏳ Pending | Needs implementation |
| Create Group UI | ⏳ Pending | Needs implementation |
| Group Conversation UI | ⏳ Pending | Needs implementation |
| Group Management UI | ⏳ Pending | Needs implementation |
| Edge Function Updates | ⏳ Pending | Add group support |

---

## 🎯 Next Steps

1. **Deploy migrations** (manually if CLI times out)
2. **Implement Groups Tab** in Inbox.tsx
3. **Create Group Dialog** component
4. **Build Group Conversation** view
5. **Add Group Management** features
6. **Update send-message** edge function
7. **Test end-to-end** workflow

---

## 💡 Technical Notes

### Differences from Direct Messages

| Aspect | Direct Messages | Group Messages |
|--------|----------------|----------------|
| Recipients | Stored in `message_recipients` | Determined by `group_members` |
| Thread ID | Required | Not used (group_id instead) |
| Read Receipts | Per recipient in `message_recipients` | Not tracked (could be added later) |
| Permissions | Hierarchical (manager → worker) | Equal (all members can send) |
| Broadcast | Creates multiple recipient records | Single message to group |

### Performance Considerations

- Index on `messages.group_id` for fast group message queries
- Index on `group_members(group_id, user_id)` for membership checks
- Consider pagination for large groups with many messages
- Realtime subscriptions for live updates (optional)

### Future Enhancements

- [ ] Group message read receipts
- [ ] Typing indicators
- [ ] Message reactions
- [ ] Pinned messages
- [ ] Group roles beyond admin/member
- [ ] Group permissions (who can add members, etc.)
- [ ] Group search/discovery
- [ ] Group invitations
- [ ] Message notifications specific to groups

---

## 📚 Reference

- **Compose.tsx**: Example of recipient selection UI
- **Thread.tsx**: Example of conversation view
- **Broadcast.tsx**: Example of attachment handling
- **Inbox.tsx**: Example of message list with tabs
- **send-message edge function**: Message creation logic

