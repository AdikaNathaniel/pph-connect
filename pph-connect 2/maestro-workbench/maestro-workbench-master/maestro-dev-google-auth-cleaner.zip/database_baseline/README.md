# Database Baseline Schema

## Overview

This directory contains the **baseline database schema** for Maestro Workbench **before** the messaging feature integration. These files serve as a reference point for understanding the original database structure and comparing changes after new features are added.

**Created:** 2025-10-29
**Source:** Consolidated from 47 migration files (Sept 28 - Oct 29, 2025)
**Purpose:** Reference, documentation, and comparison baseline

---

## Files in This Directory

### 1. `BASELINE_SCHEMA_COMPLETE.sql` (~1500 lines)

**What:** Complete, production-ready database schema with all components

**Contains:**
- All 14 tables with complete definitions
- All 20+ database functions
- All 40+ Row-Level Security (RLS) policies
- 3 analytics views
- 25+ performance indexes
- 8 triggers
- 1 storage bucket
- Properly ordered by dependencies

**When to use:**
- Creating a fresh database from scratch
- Understanding the complete system architecture
- Comparing with post-messaging schema
- Disaster recovery baseline

**How to execute:**
```bash
# Via Supabase CLI
supabase db reset --db-url "postgresql://..."

# Via psql
psql -h <host> -U postgres -d postgres -f BASELINE_SCHEMA_COMPLETE.sql

# Via Supabase Dashboard
# Copy-paste into SQL Editor and run
```

---

### 2. `BASELINE_SCHEMA_TABLES_ONLY.sql` (~280 lines)

**What:** Simplified schema with tables, enums, and constraints only

**Contains:**
- 1 enum: user_role
- 14 tables with columns and types
- Primary keys and foreign keys
- CHECK constraints and UNIQUE constraints

**Does NOT contain:**
- Indexes
- Functions
- Triggers
- RLS policies
- Views

**When to use:**
- Generating ERD diagrams
- Quick reference for table structure
- Understanding data model relationships
- Database migration planning

**Tools for ERD generation:**
```bash
# Using dbdiagram.io
# Copy table definitions and paste into https://dbdiagram.io/

# Using SchemaSpy
java -jar schemaspy.jar -t pgsql -db postgres -s public -u postgres -p password

# Using DBeaver
# Import SQL → Generate ER Diagram
```

---

### 3. `BASELINE_SCHEMA_FUNCTIONS.sql` (~600 lines)

**What:** All database functions categorized by purpose

**Contains:**
- 1 utility function (update_updated_at_column)
- 3 security helper functions (is_root, is_root_or_manager, can_send_messages)
- 4 user management functions
- 2 ID generation functions
- 9 task management functions
- 1 analytics function

**When to use:**
- Understanding business logic
- Reference for function signatures
- Testing function behavior
- Creating function documentation

**Key functions to review:**
- `claim_next_available_question()` - Atomic task claiming with locking
- `is_root_or_manager()` - Security helper for RLS policies
- `generate_question_id()` - Unique ID generation pattern

---

### 4. `BASELINE_SCHEMA_RLS_POLICIES.sql` (~365 lines)

**What:** All Row-Level Security policies organized by table

**Contains:**
- 40+ RLS policies
- Role-based access control rules
- Project-based scoping for workers
- User-based scoping for personal data

**Security Model:**
```
root       → Full access to everything
manager    → Full access (via is_root_or_manager helper)
team_lead  → Similar to worker (extended messaging in future)
worker     → Can only access assigned projects and own data
```

**When to use:**
- Understanding security model
- Debugging permission issues
- Extending security policies
- Security audit and review

**Key patterns:**
```sql
-- Admin Access Pattern
CREATE POLICY "Root and managers can view all profiles"
    ON public.profiles FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Self-Access Pattern
CREATE POLICY "Users can view their own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

-- Project-Based Access Pattern
CREATE POLICY "Workers can view assigned projects"
    ON public.projects FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.project_assignments
            WHERE worker_id = auth.uid()
              AND project_id = projects.id
        )
    );
```

---

### 5. `BASELINE_SCHEMA_SUMMARY.md`

**What:** Comprehensive human-readable documentation

**Contains:**
- ERD diagram in Mermaid format
- Detailed table descriptions with all columns
- Security model explanation
- Key functions documentation
- Analytics views description
- Complete migration history (47 files)
- Schema statistics
- Next steps for messaging implementation

**When to use:**
- Onboarding new developers
- Architecture reviews
- Understanding system design
- Planning new features

---

## Database Statistics

| Metric | Count |
|--------|-------|
| **Tables** | 14 |
| **Functions** | 20+ |
| **RLS Policies** | 40+ |
| **Views** | 3 |
| **Indexes** | 25+ |
| **Triggers** | 8 |
| **Storage Buckets** | 1 |
| **Enums** | 1 |

---

## Table Organization

### User Management (2 tables)
- `profiles` - User accounts with roles
- `user_invitations` - Invitation system

### Training (2 tables)
- `training_modules` - Training content
- `worker_training_completions` - Training tracking

### Projects & Templates (3 tables)
- `task_templates` - Reusable task templates
- `projects` - Active projects
- `project_assignments` - Worker-to-project mapping

### Tasks & Questions (4 tables)
- `questions` - Questions requiring answers (with replication)
- `tasks` - Individual task assignments
- `answers` - Worker answers to questions
- `task_answers` - Answers for specific tasks

### Logging & Analytics (3 tables)
- `task_answer_events` - Event tracking for analytics
- `client_logs` - Frontend error logging
- `worker_plugin_metrics` - Plugin performance metrics

---

## How to Compare with Post-Messaging Schema

After implementing the messaging feature, you can compare schemas:

```bash
# Generate post-messaging schema
supabase db dump --schema public > post_messaging_schema.sql

# Compare with baseline (using diff)
diff BASELINE_SCHEMA_COMPLETE.sql post_messaging_schema.sql > messaging_changes.diff

# Compare specific components
diff BASELINE_SCHEMA_TABLES_ONLY.sql post_messaging_tables.sql
diff BASELINE_SCHEMA_FUNCTIONS.sql post_messaging_functions.sql
diff BASELINE_SCHEMA_RLS_POLICIES.sql post_messaging_rls.sql

# Using specialized tools
# Use pgAdmin Schema Diff tool
# Use Liquibase diff
# Use Flyway diff
```

---

## Related Files

- **Implementation Tasks:** `../MESSAGING_IMPLEMENTATION_TASKS.md`
- **Integration Plan:** `../MESSAGING_FEATURE_IMPLEMENTATION_PLAN.md`
- **Migrations Directory:** `../supabase/migrations/`
- **First Messaging Migration:** `../supabase/migrations/20251029_001_extend_user_roles.sql`
- **Migration Tests:** `../supabase/migrations/tests/`

---

## Migration History Summary

The baseline schema was built through 47 migrations from **Sept 28, 2025** to **Oct 29, 2025**:

### Phase 1: Foundation (Sept 28-30)
- Initial schema with profiles, roles, enums
- Basic security setup with RLS policies
- Helper functions (is_root, is_root_or_manager)

### Phase 2: Core Features (Oct 1-15)
- Questions and answers system
- Task claiming with atomic locking
- Replication system for multi-worker validation
- Task reservation with time limits

### Phase 3: Advanced Features (Oct 16-25)
- Training modules and completions
- Project assignments with priorities
- Multi-modality support (audio, video, text, etc.)
- Analytics and reporting

### Phase 4: Polish & Security (Oct 26-29)
- Security fixes and RLS refinements
- Performance optimizations with indexes
- Client-side logging system
- Worker plugin metrics

---

## Next Steps (Messaging Integration)

1. **Review Baseline:** Understand current schema using these files
2. **Execute Migration 001:** Add 'admin' and 'team_lead' roles + can_send_messages() function
3. **Execute Migrations 002-006:** Add messaging tables, functions, RLS policies
4. **Compare:** Generate new schema dump and diff with baseline
5. **Document:** Update BASELINE_SCHEMA_SUMMARY.md with messaging additions

---

## Best Practices

### For Database Changes:
1. **Always reference baseline** before making schema changes
2. **Use migrations** for all schema modifications (never edit baseline files)
3. **Test with TDD** - write tests before migrations
4. **Document changes** in migration file headers

### For New Features:
1. **Review relevant baseline files** (tables, functions, RLS)
2. **Plan backward compatibility** (use IF NOT EXISTS, nullable columns)
3. **Update documentation** after changes
4. **Generate post-implementation diff** for review

### For Troubleshooting:
1. **Check RLS policies** in BASELINE_SCHEMA_RLS_POLICIES.sql
2. **Review function logic** in BASELINE_SCHEMA_FUNCTIONS.sql
3. **Verify table structure** in BASELINE_SCHEMA_TABLES_ONLY.sql
4. **Compare with production** using schema dump

---

## Questions or Issues?

If you encounter problems with these baseline files:

1. **Schema doesn't match production?**
   - These files reflect the state as of Oct 29, 2025
   - Check migration history for any newer migrations

2. **Need to regenerate baseline?**
   ```bash
   supabase db dump --schema public > new_baseline.sql
   ```

3. **Want to restore to baseline?**
   - Use BASELINE_SCHEMA_COMPLETE.sql
   - Requires dropping all existing objects first
   - **WARNING: This will delete all data!**

4. **Need help understanding a table/function?**
   - Check BASELINE_SCHEMA_SUMMARY.md for detailed documentation
   - Review inline comments in individual SQL files

---

## File Maintenance

These baseline files should be **immutable** - they represent a snapshot in time. If the database schema evolves significantly beyond messaging:

1. Create a new baseline directory: `database_baseline_v2/`
2. Generate new baseline files
3. Document what changed between versions
4. Keep old baselines for historical reference

---

## License & Attribution

Part of the Maestro Workbench project.
Baseline created: 2025-10-29
Consolidated from 47 migration files spanning Sept-Oct 2025.
