-- ============================================================================
-- MAESTRO WORKBENCH - BASELINE SCHEMA (RLS POLICIES ONLY)
-- ============================================================================
--
-- Created: 2025-10-29
-- Purpose: Row-Level Security policies for all tables
-- Total Tables with RLS: 13
--
-- Security Model:
--   - Role Hierarchy: root > admin > manager > team_lead > worker
--   - Workers: Can only access their assigned data
--   - Managers/Root: Can access all data
--   - Helper Functions: is_root(), is_root_or_manager(), can_send_messages()
--
-- Tables Covered:
--   1. profiles
--   2. user_invitations
--   3. task_templates
--   4. projects
--   5. project_assignments
--   6. questions
--   7. tasks
--   8. answers
--   9. task_answers
--   10. worker_training_completions
--   11. task_answer_events
--   12. client_logs
--   13. worker_plugin_metrics
--
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.worker_training_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_answer_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.worker_plugin_metrics ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- 1. PROFILES TABLE RLS POLICIES
-- ============================================================================

-- Users can view their own profile
CREATE POLICY "Users can view their own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

-- Root and managers can view all profiles
CREATE POLICY "Root and managers can view all profiles"
    ON public.profiles FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Root and managers can update profiles
CREATE POLICY "Root and managers can update profiles"
    ON public.profiles FOR UPDATE
    USING (public.is_root_or_manager(auth.uid()));

-- Users can update their own profile
CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id);

-- Root and managers can create profiles
CREATE POLICY "Root and managers can create profiles"
    ON public.profiles FOR INSERT
    WITH CHECK (public.is_root_or_manager(auth.uid()));

-- Root can delete profiles
CREATE POLICY "Root can delete profiles"
    ON public.profiles FOR DELETE
    USING (public.is_root(auth.uid()));

-- ============================================================================
-- 2. USER INVITATIONS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can manage all invitations
CREATE POLICY "Root and managers can manage invitations"
    ON public.user_invitations FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- ============================================================================
-- 3. TASK TEMPLATES TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can manage all templates
CREATE POLICY "Root and managers can manage templates"
    ON public.task_templates FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view templates (read-only)
CREATE POLICY "Workers can view templates"
    ON public.task_templates FOR SELECT
    USING (true);

-- ============================================================================
-- 4. PROJECTS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can manage all projects
CREATE POLICY "Root and managers can manage projects"
    ON public.projects FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view projects they are assigned to
CREATE POLICY "Workers can view assigned projects"
    ON public.projects FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.project_assignments
            WHERE worker_id = auth.uid()
              AND project_id = projects.id
        )
    );

-- ============================================================================
-- 5. PROJECT ASSIGNMENTS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can manage all assignments
CREATE POLICY "Root and managers can manage assignments"
    ON public.project_assignments FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view their own assignments
CREATE POLICY "Workers can view their assignments"
    ON public.project_assignments FOR SELECT
    USING (worker_id = auth.uid());

-- ============================================================================
-- 6. QUESTIONS TABLE RLS POLICIES
-- ============================================================================

-- Managers can view all questions
CREATE POLICY "Managers can view all questions"
    ON public.questions FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view questions from their assigned projects
CREATE POLICY "Workers can view assigned project questions"
    ON public.questions FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.project_assignments
            WHERE worker_id = auth.uid()
              AND project_id = questions.project_id
        )
    );

-- Workers can update question completion status (via trigger)
CREATE POLICY "Workers can update question completion"
    ON public.questions FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM public.project_assignments
            WHERE worker_id = auth.uid()
              AND project_id = questions.project_id
        )
    );

-- Managers can update all questions
CREATE POLICY "Managers can update all questions"
    ON public.questions FOR UPDATE
    USING (public.is_root_or_manager(auth.uid()));

-- ============================================================================
-- 7. TASKS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can manage all tasks
CREATE POLICY "Root and managers can manage all tasks"
    ON public.tasks FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view their assigned tasks
CREATE POLICY "Workers can view their assigned tasks"
    ON public.tasks FOR SELECT
    USING (assigned_to = auth.uid());

-- Workers can update their assigned tasks (for releasing)
CREATE POLICY "Workers can update their assigned tasks"
    ON public.tasks FOR UPDATE
    USING (assigned_to = auth.uid());

-- ============================================================================
-- 8. ANSWERS TABLE RLS POLICIES
-- ============================================================================

-- Managers can view all answers
CREATE POLICY "Managers can view all answers"
    ON public.answers FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view their own answers
CREATE POLICY "Workers can view their own answers"
    ON public.answers FOR SELECT
    USING (worker_id = auth.uid());

-- Workers can insert their own answers
CREATE POLICY "Workers can insert their own answers"
    ON public.answers FOR INSERT
    WITH CHECK (worker_id = auth.uid());

-- ============================================================================
-- 9. TASK ANSWERS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can view all task answers
CREATE POLICY "Root and managers can view all task answers"
    ON public.task_answers FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can view their own task answers
CREATE POLICY "Workers can view their own task answers"
    ON public.task_answers FOR SELECT
    USING (worker_id = auth.uid());

-- Workers can insert their own task answers
CREATE POLICY "Workers can insert their own task answers"
    ON public.task_answers FOR INSERT
    WITH CHECK (worker_id = auth.uid());

-- ============================================================================
-- 10. WORKER TRAINING COMPLETIONS TABLE RLS POLICIES
-- ============================================================================

-- Workers can view their own training completions
CREATE POLICY "Workers can view their own training completions"
    ON public.worker_training_completions FOR SELECT
    USING (worker_id = auth.uid());

-- Workers can insert their own training completions
CREATE POLICY "Workers can insert their own training completions"
    ON public.worker_training_completions FOR INSERT
    WITH CHECK (worker_id = auth.uid());

-- Workers can update their own training completions
CREATE POLICY "Workers can update their own training completions"
    ON public.worker_training_completions FOR UPDATE
    USING (worker_id = auth.uid());

-- Root and managers can view all training completions
CREATE POLICY "Root and managers can view all training completions"
    ON public.worker_training_completions FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Root and managers can manage all training completions
CREATE POLICY "Root and managers can manage training completions"
    ON public.worker_training_completions FOR ALL
    USING (public.is_root_or_manager(auth.uid()));

-- ============================================================================
-- 11. TASK ANSWER EVENTS TABLE RLS POLICIES
-- ============================================================================

-- Root and managers can view all events
CREATE POLICY "Root and managers can view all events"
    ON public.task_answer_events FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- Workers can insert their own events
CREATE POLICY "Workers can insert their own events"
    ON public.task_answer_events FOR INSERT
    WITH CHECK (worker_id = auth.uid());

-- Workers can view their own events
CREATE POLICY "Workers can view their own events"
    ON public.task_answer_events FOR SELECT
    USING (worker_id = auth.uid());

-- ============================================================================
-- 12. CLIENT LOGS TABLE RLS POLICIES
-- ============================================================================

-- Workers can insert client logs
CREATE POLICY "Workers can insert client logs"
    ON public.client_logs FOR INSERT
    WITH CHECK (worker_id = auth.uid());

-- Managers can view all client logs
CREATE POLICY "Managers can view client logs"
    ON public.client_logs FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- ============================================================================
-- 13. WORKER PLUGIN METRICS TABLE RLS POLICIES
-- ============================================================================

-- Workers can view their own plugin metrics
CREATE POLICY "Workers can view their plugin metrics"
    ON public.worker_plugin_metrics FOR SELECT
    USING (worker_id = auth.uid());

-- Workers can manage their own plugin metrics
CREATE POLICY "Workers can manage their plugin metrics"
    ON public.worker_plugin_metrics FOR ALL
    USING (worker_id = auth.uid());

-- Managers can view all plugin metrics
CREATE POLICY "Managers can view all plugin metrics"
    ON public.worker_plugin_metrics FOR SELECT
    USING (public.is_root_or_manager(auth.uid()));

-- ============================================================================
-- RLS POLICY SUMMARY
-- ============================================================================
--
-- Total Policies: 40+
--
-- Access Pattern Summary:
--
-- ROOT ROLE:
--   - Full access to all tables (via is_root() helper)
--   - Can delete profiles
--   - Can assign root role to others
--
-- MANAGER ROLE:
--   - Full access to all tables (via is_root_or_manager() helper)
--   - Can create/manage users (except root)
--   - Can view all worker data
--   - Can manage projects, templates, assignments
--
-- TEAM_LEAD ROLE:
--   - Similar to worker for now
--   - Extended permissions for messaging (future)
--
-- WORKER ROLE:
--   - Can view own profile
--   - Can view assigned projects only
--   - Can view/insert own answers
--   - Can view/update assigned tasks
--   - Can insert client logs
--   - Can manage own training completions
--   - Can manage own plugin metrics
--
-- Security Mechanisms:
--   1. Helper Functions (SECURITY DEFINER to avoid recursion)
--      - is_root(uuid)
--      - is_root_or_manager(uuid)
--      - can_send_messages(uuid)
--
--   2. Project-Based Scoping (for workers)
--      - EXISTS clause checks project_assignments table
--      - Ensures workers only see assigned project data
--
--   3. User-Based Scoping (for workers)
--      - auth.uid() = worker_id
--      - Ensures workers only see their own data
--
--   4. Operation-Specific Policies
--      - Separate policies for SELECT, INSERT, UPDATE, DELETE
--      - Different access levels for different operations
--
-- ============================================================================
-- END
-- ============================================================================
