-- ============================================================================
-- MAESTRO WORKBENCH - BASELINE SCHEMA (TABLES ONLY)
-- ============================================================================
--
-- Created: 2025-10-29
-- Purpose: Simplified schema with tables, enums, and constraints only
-- Usage: Quick reference, ERD generation, documentation
--
-- Contents:
--   - Enums
--   - Table definitions with columns and types
--   - Primary keys and foreign keys
--   - Basic constraints (CHECK, UNIQUE, NOT NULL)
--
-- Does NOT include:
--   - Indexes (see BASELINE_SCHEMA_COMPLETE.sql)
--   - Functions (see BASELINE_SCHEMA_FUNCTIONS.sql)
--   - Triggers
--   - RLS Policies (see BASELINE_SCHEMA_RLS_POLICIES.sql)
--   - Views
--
-- ============================================================================

-- ============================================================================
-- ENUMS
-- ============================================================================

CREATE TYPE public.user_role AS ENUM (
    'root',       -- Super administrator
    'admin',      -- Administrator
    'manager',    -- Project manager
    'team_lead',  -- Team leader
    'worker'      -- Standard worker (default)
);

-- ============================================================================
-- TABLES
-- ============================================================================

-- ----------------------------------------------------------------------------
-- User Management
-- ----------------------------------------------------------------------------

CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role public.user_role NOT NULL DEFAULT 'worker',
    initial_password_hash TEXT,
    password_changed_at TIMESTAMPTZ,
    suspended BOOLEAN NOT NULL DEFAULT false,
    last_sign_in_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.user_invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL,
    role public.user_role NOT NULL,
    invited_by UUID NOT NULL REFERENCES public.profiles(id),
    initial_password_hash TEXT NOT NULL,
    invited_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
    used BOOLEAN NOT NULL DEFAULT false
);

-- ----------------------------------------------------------------------------
-- Training
-- ----------------------------------------------------------------------------

CREATE TABLE public.training_modules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT,
    content TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.worker_training_completions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    training_module_id UUID REFERENCES public.training_modules(id) ON DELETE CASCADE,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ,
    duration_seconds INTEGER,
    completed_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(worker_id, training_module_id, project_id)
);

-- ----------------------------------------------------------------------------
-- Projects & Templates
-- ----------------------------------------------------------------------------

CREATE TABLE public.task_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    google_sheet_url TEXT NOT NULL,
    column_config JSONB NOT NULL DEFAULT '[]',
    modality TEXT NOT NULL DEFAULT 'spreadsheet' CHECK (
        modality IN ('spreadsheet', 'audio-short', 'audio-long', 'text', 'image', 'video', 'multimodal')
    ),
    modality_config JSONB DEFAULT '{}',
    label_ontology JSONB DEFAULT NULL,
    created_by UUID NOT NULL REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    template_id UUID NOT NULL REFERENCES public.task_templates(id) ON DELETE RESTRICT,
    language TEXT,
    locale TEXT DEFAULT 'en_us',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed')),
    google_sheet_url TEXT NOT NULL,
    total_tasks INTEGER DEFAULT 0,
    completed_tasks INTEGER DEFAULT 0,
    replications_per_question INTEGER NOT NULL DEFAULT 1,
    training_module_id UUID REFERENCES public.training_modules(id) ON DELETE SET NULL,
    training_required BOOLEAN DEFAULT false,
    reservation_time_limit_minutes INTEGER NOT NULL DEFAULT 60,
    average_handle_time_minutes INTEGER,
    enable_skip_button BOOLEAN NOT NULL DEFAULT false,
    skip_reasons JSONB NOT NULL DEFAULT '[]',
    instructions TEXT,
    instructions_pdf_url TEXT,
    instructions_google_docs_url TEXT,
    due_date TIMESTAMPTZ,
    created_by UUID NOT NULL REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.project_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    priority INTEGER NOT NULL DEFAULT 50,
    assigned_by UUID NOT NULL REFERENCES public.profiles(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(worker_id, project_id)
);

-- ----------------------------------------------------------------------------
-- Tasks & Questions
-- ----------------------------------------------------------------------------

CREATE TABLE public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    question_id TEXT NOT NULL,
    row_index INTEGER NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    required_replications INTEGER NOT NULL DEFAULT 1,
    completed_replications INTEGER NOT NULL DEFAULT 0,
    is_answered BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(project_id, question_id)
);

CREATE TABLE public.tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    question_id UUID REFERENCES public.questions(id) ON DELETE CASCADE,
    row_index INTEGER NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'completed')),
    assigned_to UUID REFERENCES public.profiles(id),
    assigned_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    completion_time_seconds INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.answers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    answer_id TEXT NOT NULL UNIQUE,
    worker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    answer_data JSONB NOT NULL DEFAULT '{}',
    start_time TIMESTAMPTZ NOT NULL,
    completion_time TIMESTAMPTZ NOT NULL,
    aht_seconds INTEGER NOT NULL,
    skipped BOOLEAN NOT NULL DEFAULT false,
    skip_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.task_answers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
    worker_id UUID NOT NULL REFERENCES public.profiles(id),
    project_id UUID NOT NULL REFERENCES public.projects(id),
    answer_data JSONB NOT NULL DEFAULT '{}',
    start_time TIMESTAMPTZ NOT NULL,
    completion_time TIMESTAMPTZ NOT NULL,
    aht_seconds INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- Logging & Analytics
-- ----------------------------------------------------------------------------

CREATE TABLE public.task_answer_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL,
    task_id UUID NOT NULL,
    worker_id UUID NOT NULL,
    event_type TEXT NOT NULL,
    field_id TEXT,
    field_name TEXT,
    details JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.client_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
    level TEXT NOT NULL CHECK (level IN ('info', 'warn', 'error')),
    message TEXT NOT NULL,
    context TEXT,
    metadata JSONB,
    stack TEXT,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.worker_plugin_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    plugin_type TEXT NOT NULL,
    metric_key TEXT NOT NULL,
    metric_value NUMERIC NOT NULL,
    metric_unit TEXT,
    metric_metadata JSONB NOT NULL DEFAULT '{}',
    recorded_at DATE NOT NULL DEFAULT current_date,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- TABLE SUMMARY
-- ============================================================================

-- Total Tables: 14
--
-- User Management (2):
--   - profiles
--   - user_invitations
--
-- Training (2):
--   - training_modules
--   - worker_training_completions
--
-- Projects & Templates (3):
--   - task_templates
--   - projects
--   - project_assignments
--
-- Tasks & Questions (4):
--   - questions
--   - tasks
--   - answers
--   - task_answers
--
-- Logging & Analytics (3):
--   - task_answer_events
--   - client_logs
--   - worker_plugin_metrics
--
-- ============================================================================
-- END
-- ============================================================================
