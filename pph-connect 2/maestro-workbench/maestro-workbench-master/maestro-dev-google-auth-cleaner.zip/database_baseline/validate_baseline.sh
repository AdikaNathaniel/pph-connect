#!/bin/bash
# ============================================================================
# BASELINE SCHEMA VALIDATION SCRIPT
# ============================================================================
# Purpose: Validate all baseline schema files for completeness and correctness
# Usage: bash validate_baseline.sh

set -e

BASELINE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PASS_COUNT=0
FAIL_COUNT=0
TOTAL_TESTS=0

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "============================================================================"
echo "BASELINE SCHEMA VALIDATION"
echo "============================================================================"
echo ""

# Helper functions
pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    ((PASS_COUNT++))
    ((TOTAL_TESTS++))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    ((FAIL_COUNT++))
    ((TOTAL_TESTS++))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
}

# Test 1: Check all required files exist
echo "Test 1: Checking file existence..."
echo "-----------------------------------"

required_files=(
    "BASELINE_SCHEMA_COMPLETE.sql"
    "BASELINE_SCHEMA_TABLES_ONLY.sql"
    "BASELINE_SCHEMA_FUNCTIONS.sql"
    "BASELINE_SCHEMA_RLS_POLICIES.sql"
    "BASELINE_SCHEMA_SUMMARY.md"
    "README.md"
)

for file in "${required_files[@]}"; do
    if [ -f "$BASELINE_DIR/$file" ]; then
        pass "File exists: $file"
    else
        fail "File missing: $file"
    fi
done
echo ""

# Test 2: Check file sizes are reasonable
echo "Test 2: Checking file sizes..."
echo "-------------------------------"

check_file_size() {
    local file="$1"
    local min_size="$2"
    local filepath="$BASELINE_DIR/$file"

    if [ -f "$filepath" ]; then
        size=$(wc -c < "$filepath")
        if [ "$size" -gt "$min_size" ]; then
            pass "File size OK: $file (${size} bytes, min: ${min_size})"
        else
            fail "File too small: $file (${size} bytes, expected min: ${min_size})"
        fi
    fi
}

check_file_size "BASELINE_SCHEMA_COMPLETE.sql" 50000
check_file_size "BASELINE_SCHEMA_TABLES_ONLY.sql" 8000
check_file_size "BASELINE_SCHEMA_FUNCTIONS.sql" 15000
check_file_size "BASELINE_SCHEMA_RLS_POLICIES.sql" 12000
check_file_size "BASELINE_SCHEMA_SUMMARY.md" 15000
check_file_size "README.md" 8000
echo ""

# Test 3: Check SQL syntax (basic validation)
echo "Test 3: Checking SQL syntax basics..."
echo "--------------------------------------"

check_sql_syntax() {
    local file="$1"
    local filepath="$BASELINE_DIR/$file"

    if [ -f "$filepath" ]; then
        # Check for unclosed strings/comments
        if grep -q "'\$" "$filepath"; then
            warn "Possible unclosed string in: $file"
        fi

        # Check for basic SQL keywords
        if grep -q "CREATE TABLE" "$filepath"; then
            pass "Contains CREATE TABLE: $file"
        elif grep -q "CREATE FUNCTION" "$filepath"; then
            pass "Contains CREATE FUNCTION: $file"
        elif grep -q "CREATE POLICY" "$filepath"; then
            pass "Contains CREATE POLICY: $file"
        else
            fail "Missing expected SQL keywords: $file"
        fi
    fi
}

check_sql_syntax "BASELINE_SCHEMA_COMPLETE.sql"
check_sql_syntax "BASELINE_SCHEMA_TABLES_ONLY.sql"
check_sql_syntax "BASELINE_SCHEMA_FUNCTIONS.sql"
check_sql_syntax "BASELINE_SCHEMA_RLS_POLICIES.sql"
echo ""

# Test 4: Check for key tables in TABLES_ONLY
echo "Test 4: Checking key tables..."
echo "-------------------------------"

TABLES_FILE="$BASELINE_DIR/BASELINE_SCHEMA_TABLES_ONLY.sql"
key_tables=("profiles" "projects" "questions" "tasks" "answers")

for table in "${key_tables[@]}"; do
    if grep -q "CREATE TABLE public.$table" "$TABLES_FILE"; then
        pass "Table found: $table"
    else
        fail "Table missing: $table"
    fi
done
echo ""

# Test 5: Check for key functions in FUNCTIONS file
echo "Test 5: Checking key functions..."
echo "----------------------------------"

FUNCTIONS_FILE="$BASELINE_DIR/BASELINE_SCHEMA_FUNCTIONS.sql"
key_functions=(
    "is_root"
    "is_root_or_manager"
    "can_send_messages"
    "claim_next_available_question"
    "generate_question_id"
)

for func in "${key_functions[@]}"; do
    if grep -q "CREATE OR REPLACE FUNCTION public.$func" "$FUNCTIONS_FILE"; then
        pass "Function found: $func"
    else
        fail "Function missing: $func"
    fi
done
echo ""

# Test 6: Check for RLS policies
echo "Test 6: Checking RLS policies..."
echo "---------------------------------"

RLS_FILE="$BASELINE_DIR/BASELINE_SCHEMA_RLS_POLICIES.sql"
key_policies=(
    "ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY"
    "ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY"
    "ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY"
)

for policy in "${key_policies[@]}"; do
    if grep -q "$policy" "$RLS_FILE"; then
        pass "RLS enabled: $(echo $policy | cut -d' ' -f4)"
    else
        fail "RLS not enabled: $(echo $policy | cut -d' ' -f4)"
    fi
done
echo ""

# Test 7: Check COMPLETE file contains all sections
echo "Test 7: Checking COMPLETE file sections..."
echo "-------------------------------------------"

COMPLETE_FILE="$BASELINE_DIR/BASELINE_SCHEMA_COMPLETE.sql"
sections=("ENUMS" "TABLES" "FUNCTIONS" "TRIGGERS" "RLS POLICIES" "INDEXES" "VIEWS")

for section in "${sections[@]}"; do
    if grep -q "-- $section" "$COMPLETE_FILE"; then
        pass "Section found: $section"
    else
        fail "Section missing: $section"
    fi
done
echo ""

# Test 8: Check README has key sections
echo "Test 8: Checking README sections..."
echo "------------------------------------"

README_FILE="$BASELINE_DIR/README.md"
readme_sections=("Overview" "Files in This Directory" "Database Statistics" "How to Compare" "Migration History")

for section in "${readme_sections[@]}"; do
    if grep -q "## $section" "$README_FILE"; then
        pass "README section found: $section"
    else
        fail "README section missing: $section"
    fi
done
echo ""

# Test 9: Check SUMMARY has ERD diagram
echo "Test 9: Checking SUMMARY documentation..."
echo "------------------------------------------"

SUMMARY_FILE="$BASELINE_DIR/BASELINE_SCHEMA_SUMMARY.md"
if grep -q "```mermaid" "$SUMMARY_FILE"; then
    pass "ERD diagram found in SUMMARY"
else
    fail "ERD diagram missing from SUMMARY"
fi

if grep -q "Migration History" "$SUMMARY_FILE"; then
    pass "Migration history found in SUMMARY"
else
    fail "Migration history missing from SUMMARY"
fi
echo ""

# Final Summary
echo "============================================================================"
echo "VALIDATION SUMMARY"
echo "============================================================================"
echo ""
echo "Total Tests: $TOTAL_TESTS"
echo -e "Passed: ${GREEN}$PASS_COUNT${NC}"
echo -e "Failed: ${RED}$FAIL_COUNT${NC}"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo -e "${GREEN}✓ ALL TESTS PASSED${NC}"
    echo ""
    echo "All baseline files are valid and complete."
    echo "Ready for reference and comparison."
    exit 0
else
    echo -e "${RED}✗ SOME TESTS FAILED${NC}"
    echo ""
    echo "Please review failed tests above and regenerate affected files."
    exit 1
fi
