# Maestro Workbench - Database Schema Summary

**Created:** 2025-10-29
**Database:** PostgreSQL 15+ (Supabase)
**Total Tables:** 14
**Total Functions:** 20+
**Total Views:** 3

---

## Table of Contents

1. [Overview](#overview)
2. [Entity Relationship Diagram](#entity-relationship-diagram)
3. [Table Descriptions](#table-descriptions)
4. [Security Model](#security-model)
5. [Key Functions](#key-functions)
6. [Analytics Views](#analytics-views)
7. [Migration History](#migration-history)

---

## Overview

Maestro Workbench is a sophisticated task management and annotation platform built on Supabase (PostgreSQL). The database schema supports:

- **Multi-role user management** (root, admin, manager, team_lead, worker)
- **Question/Answer task distribution** with replication support
- **Atomic task claiming** with reservation system
- **Training module** integration
- **Multi-modality support** (audio, text, image, video, spreadsheet)
- **Worker analytics** and performance tracking
- **Comprehensive audit logging**

### Core Concepts

1. **Projects**: Annotation projects created from templates
2. **Questions**: Individual items that need answers
3. **Tasks**: Temporary reservations of questions by workers
4. **Answers**: Worker submissions for questions
5. **Replications**: Multiple workers can answer the same question
6. **Training**: Required training modules before accessing projects

---

## Entity Relationship Diagram

```mermaid
erDiagram
    PROFILES ||--o{ USER_INVITATIONS : "invites"
    PROFILES ||--o{ TASK_TEMPLATES : "creates"
    PROFILES ||--o{ PROJECTS : "creates"
    PROFILES ||--o{ PROJECT_ASSIGNMENTS : "assigned_to"
    PROFILES ||--o{ TASKS : "assigned_to"
    PROFILES ||--o{ ANSWERS : "submits"
    PROFILES ||--o{ WORKER_TRAINING_COMPLETIONS : "completes"

    TASK_TEMPLATES ||--o{ PROJECTS : "uses"
    TRAINING_MODULES ||--o{ PROJECTS : "requires"
    TRAINING_MODULES ||--o{ WORKER_TRAINING_COMPLETIONS : "tracks"

    PROJECTS ||--o{ PROJECT_ASSIGNMENTS : "has"
    PROJECTS ||--o{ QUESTIONS : "contains"
    PROJECTS ||--o{ TASKS : "contains"
    PROJECTS ||--o{ ANSWERS : "receives"
    PROJECTS ||--o{ WORKER_TRAINING_COMPLETIONS : "gates"

    QUESTIONS ||--o{ TASKS : "reserved_as"
    QUESTIONS ||--o{ ANSWERS : "answered_by"

    TASKS ||--o{ TASK_ANSWERS : "has"

    PROFILES {
        uuid id PK
        text email
        text full_name
        user_role role
        boolean suspended
        timestamptz last_sign_in_at
    }

    PROJECTS {
        uuid id PK
        text name
        uuid template_id FK
        text status
        int replications_per_question
        int reservation_time_limit_minutes
    }

    QUESTIONS {
        uuid id PK
        uuid project_id FK
        text question_id UK
        int required_replications
        int completed_replications
        boolean is_answered
    }

    TASKS {
        uuid id PK
        uuid project_id FK
        uuid question_id FK
        uuid assigned_to FK
        text status
        timestamptz assigned_at
    }

    ANSWERS {
        uuid id PK
        uuid question_id FK
        uuid project_id FK
        uuid worker_id FK
        text answer_id UK
        jsonb answer_data
        int aht_seconds
    }
```

---

## Table Descriptions

### User Management

#### **profiles**
Extends Supabase auth.users with application-specific data.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | References auth.users(id) |
| email | TEXT | User email address |
| full_name | TEXT | User's full name |
| role | user_role | Role: root/admin/manager/team_lead/worker |
| suspended | BOOLEAN | If true, user cannot access system |
| initial_password_hash | TEXT | For first-time login detection |
| password_changed_at | TIMESTAMPTZ | Last password change |
| last_sign_in_at | TIMESTAMPTZ | Last login timestamp |

**Key Relationships:**
- Creates projects, templates, assignments
- Receives project assignments
- Claims tasks
- Submits answers

#### **user_invitations**
Pending user invitations created by managers.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Invitation ID |
| email | TEXT | Invited user's email |
| role | user_role | Assigned role |
| invited_by | UUID (FK) | Manager who created invitation |
| initial_password_hash | TEXT | Hashed initial password |
| expires_at | TIMESTAMPTZ | Expiration (7 days default) |
| used | BOOLEAN | Whether invitation was used |

---

### Projects & Templates

#### **task_templates**
Reusable task configurations with column definitions.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Template ID |
| name | TEXT | Template name |
| google_sheet_url | TEXT | Source sheet URL |
| column_config | JSONB | Form field definitions |
| modality | TEXT | Type: spreadsheet, audio, text, image, video |
| modality_config | JSONB | Modality-specific settings |
| label_ontology | JSONB | For annotation tasks |
| created_by | UUID (FK) | Creator profile ID |

**Modality Types:**
- `spreadsheet`: Standard spreadsheet tasks
- `audio-short`: Short audio clips
- `audio-long`: Long-form audio
- `text`: Text annotation
- `image`: Image labeling
- `video`: Video annotation
- `multimodal`: Multiple types

#### **projects**
Active annotation projects with configuration.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Project ID |
| name | TEXT | Project name |
| template_id | UUID (FK) | Task template |
| status | TEXT | active / paused / completed |
| replications_per_question | INTEGER | How many workers answer each question |
| reservation_time_limit_minutes | INTEGER | Task reservation timeout (default: 60) |
| average_handle_time_minutes | INTEGER | Expected AHT |
| enable_skip_button | BOOLEAN | Allow workers to skip |
| skip_reasons | JSONB | Allowed skip reasons |
| training_module_id | UUID (FK) | Required training |
| training_required | BOOLEAN | Gates project access |

**Key Configuration:**
- **Replication**: Each question can be answered by multiple workers
- **Reservation Timeout**: Workers must complete tasks within time limit
- **Training**: Optional training module requirement

#### **project_assignments**
Many-to-many relationship: workers ↔ projects.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Assignment ID |
| worker_id | UUID (FK) | Assigned worker |
| project_id | UUID (FK) | Assigned project |
| priority | INTEGER | Priority (0=highest, 100=lowest) |
| assigned_by | UUID (FK) | Manager who assigned |

**Business Rules:**
- Workers can be assigned to multiple projects
- Priority determines project selection order
- UNIQUE constraint on (worker_id, project_id)

---

### Tasks & Questions

#### **questions**
Individual questions/rows from projects requiring answers.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Question ID |
| project_id | UUID (FK) | Parent project |
| question_id | TEXT (UK) | Unique ID: 24char+project+24char |
| row_index | INTEGER | Row number in sheet |
| data | JSONB | Question data (read-only) |
| required_replications | INTEGER | How many answers needed |
| completed_replications | INTEGER | Current answer count |
| is_answered | BOOLEAN | Fully answered? |

**Question Lifecycle:**
1. Created from Google Sheets
2. Available for claiming (is_answered=false, completed < required)
3. Workers claim and answer
4. After required answers submitted: is_answered=true

#### **tasks**
Temporary task reservations by workers.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Task ID |
| project_id | UUID (FK) | Parent project |
| question_id | UUID (FK) | Reserved question |
| assigned_to | UUID (FK) | Worker who claimed |
| status | TEXT | pending / assigned / completed |
| assigned_at | TIMESTAMPTZ | Reservation time |

**Reservation System:**
- Workers claim questions by creating task reservations
- Reservations expire after `reservation_time_limit_minutes`
- Expired reservations are auto-cleaned up
- Prevents duplicate claims with row-level locking

#### **answers**
Worker submissions for questions.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Answer ID |
| question_id | UUID (FK) | Answered question |
| project_id | UUID (FK) | Parent project |
| worker_id | UUID (FK) | Worker who answered |
| answer_id | TEXT (UK) | Unique ID: 24char+project+answer+24char |
| answer_data | JSONB | Worker's answer |
| start_time | TIMESTAMPTZ | When worker started |
| completion_time | TIMESTAMPTZ | When submitted |
| aht_seconds | INTEGER | Answer Handle Time |
| skipped | BOOLEAN | Was skipped? |
| skip_reason | TEXT | Why skipped |

**Answer Submission Flow:**
1. Worker claims question (creates task)
2. Worker fills out form
3. Worker submits (creates answer)
4. Trigger updates question.completed_replications
5. If completed >= required: question.is_answered = true

---

### Training

#### **training_modules**
Reusable training content.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Module ID |
| title | TEXT | Module title |
| description | TEXT | Description |
| video_url | TEXT | Training video URL |
| content | TEXT | Markdown/HTML content |

#### **worker_training_completions**
Tracks which workers completed which training.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID (PK) | Completion ID |
| worker_id | UUID (FK) | Worker |
| training_module_id | UUID (FK) | Module |
| project_id | UUID (FK) | Project requiring training |
| started_at | TIMESTAMPTZ | When started |
| duration_seconds | INTEGER | Time spent |
| completed_at | TIMESTAMPTZ | When completed |

**Training Gate:**
- Projects can require training modules
- Workers must complete training before accessing project
- Tracked per project (same module can be required multiple times)

---

### Logging & Analytics

#### **task_answer_events**
Event logging for task interactions.

| Column | Type | Description |
|--------|------|-------------|
| project_id | UUID | Project |
| task_id | UUID | Task |
| worker_id | UUID | Worker |
| event_type | TEXT | Event type (e.g., "paste_detected") |
| field_id | TEXT | Form field ID |
| details | JSONB | Event details |

**Use Cases:**
- Paste detection
- Field interaction tracking
- Debugging task issues

#### **client_logs**
Client-side error and console logging.

| Column | Type | Description |
|--------|------|-------------|
| worker_id | UUID (FK) | Worker |
| level | TEXT | info / warn / error |
| message | TEXT | Log message |
| context | TEXT | Additional context |
| metadata | JSONB | Structured data |
| stack | TEXT | Error stack trace |
| occurred_at | TIMESTAMPTZ | When logged |

**Use Cases:**
- Client-side error tracking
- Debugging user issues
- Console log centralization

#### **worker_plugin_metrics**
Extensible plugin-specific metrics.

| Column | Type | Description |
|--------|------|-------------|
| worker_id | UUID (FK) | Worker |
| plugin_type | TEXT | Plugin name |
| metric_key | TEXT | Metric name |
| metric_value | NUMERIC | Metric value |
| metric_unit | TEXT | Unit (e.g., "minutes", "count") |
| metric_metadata | JSONB | Additional data |
| recorded_at | DATE | Metric date |

**Example:**
```json
{
  "worker_id": "123...",
  "plugin_type": "audio-short",
  "metric_key": "audio_minutes_processed",
  "metric_value": 45.5,
  "metric_unit": "minutes",
  "recorded_at": "2025-10-29"
}
```

---

## Security Model

### Role Hierarchy

```
root (Super Admin)
  ↓
admin (Administrator - for messaging)
  ↓
manager (Project Manager)
  ↓
team_lead (Team Leader - for messaging)
  ↓
worker (Standard Worker)
```

### Access Control

#### ROOT Role
- Full access to all tables
- Can delete profiles
- Can assign root role to others
- Highest privilege level

#### MANAGER Role
- Full access to all tables (except cannot delete profiles)
- Can create/manage users (except root users)
- Can view all worker data
- Can manage projects, templates, assignments

#### TEAM_LEAD Role
- Currently same as worker
- Extended permissions for messaging feature (future)

#### WORKER Role
- Can view own profile only
- Can view assigned projects only
- Can view/insert own answers
- Can view/update assigned tasks
- Can insert client logs
- Can manage own training completions

### RLS Security Mechanisms

1. **Helper Functions** (SECURITY DEFINER to avoid recursion)
   - `is_root(uuid)`: Check if user is root
   - `is_root_or_manager(uuid)`: Check if user is root or manager
   - `can_send_messages(uuid)`: Check if user can send messages

2. **Project-Based Scoping** (for workers)
   ```sql
   EXISTS (
       SELECT 1 FROM project_assignments
       WHERE worker_id = auth.uid()
       AND project_id = <table>.project_id
   )
   ```

3. **User-Based Scoping** (for workers)
   ```sql
   auth.uid() = worker_id
   ```

---

## Key Functions

### Task Claiming

#### `claim_next_available_question(project_id, worker_id)`
**Purpose:** Atomically claim next available question with reservation system.

**Logic:**
1. Clean up expired reservations for worker
2. Check if worker already has reservation for this project (return if yes)
3. Check if worker has reservation for different project (block if yes)
4. Clean up expired reservations for target project
5. Find next available question with row-level locking (`FOR UPDATE SKIP LOCKED`)
6. Create task reservation
7. Return question data with reservation task ID

**Concurrency:** Uses `FOR UPDATE SKIP LOCKED` to prevent race conditions.

#### `count_claimable_questions(project_id)`
**Purpose:** Count questions available for claiming without violating reservations.

#### `count_active_reservations_for_worker(project_id, worker_id)`
**Purpose:** Count active task reservations for a worker within reservation window.

### Task Release

#### `release_worker_tasks()`
**Purpose:** Release all tasks assigned to current user.

**Returns:** `(released_count INTEGER, released_task_ids UUID[])`

#### `release_task_by_id(task_id)`
**Purpose:** Release a specific task by ID.

**Returns:** `BOOLEAN` (true if released, false if not found)

### ID Generation

#### `generate_question_id(project_name)`
**Purpose:** Generate unique question ID.

**Format:** `24char+project_name+24char`

**Example:** `abc123...xyz+MyProject+def456...uvw`

#### `generate_answer_id(question_id)`
**Purpose:** Generate unique answer ID.

**Format:** `24char+project_name+answer+24char`

**Example:** `abc123...xyz+MyProject+answer+def456...uvw`

---

## Analytics Views

### `worker_analytics_summary`
Core worker analytics aggregates derived from answers table.

**Columns:**
- `worker_id`: Worker UUID
- `total_completed_tasks`: Total answers submitted
- `distinct_projects`: Number of projects worked on
- `tasks_last_24h`: Tasks in last 24 hours
- `tasks_today`: Tasks today
- `total_active_seconds`: Total time spent
- `avg_aht_seconds`: Average Answer Handle Time
- `first_active_at`: First answer timestamp
- `last_active_at`: Last answer timestamp

### `worker_daily_activity`
Per-worker, per-project activity counts by day for charting.

**Columns:**
- `worker_id`: Worker UUID
- `project_id`: Project UUID
- `activity_date`: Date
- `tasks_completed`: Count
- `total_active_seconds`: Sum of AHT

### `worker_project_performance`
Per-project performance breakdown for each worker.

**Columns:**
- `worker_id`: Worker UUID
- `project_id`: Project UUID
- `tasks_completed`: Count
- `total_active_seconds`: Sum of AHT
- `avg_aht_seconds`: Average AHT
- `first_active_at`: First task timestamp
- `last_active_at`: Last task timestamp

---

## Migration History

### September 28-29, 2025: Foundation
- Initial base schema (profiles, templates, projects, assignments)
- Role system: manager, worker
- Basic RLS policies

### September 29-30, 2025: Enhanced Security & Tasks
- Added `root` role for super admin
- Fixed RLS recursion with SECURITY DEFINER helper functions
- Added user invitation system
- Created `tasks` table for task reservations
- Added `task_answers` table

### January 1, 2025: Question/Answer System
- Major refactor: Created `questions` and `answers` tables
- Implemented replication system
- Atomic question claiming with `claim_next_available_question()`
- ID generation functions for traceability

### October 15, 2024: Training & Configuration
- Training module system with completion tracking
- Per-project reservation time limits
- Average Handle Time (AHT) configuration
- Skip button functionality with reasons

### October 1-4, 2025: Advanced Features
- Project instruction files with storage bucket
- Worker analytics views and metrics
- Multi-modality support (audio, text, image, video)

### October 15-18, 2025: Bug Fixes & Optimization
- Allow multiple project assignments per worker
- Client-side logging table
- Fixed training completions RLS policies
- Comprehensive claim function fixes
- Task release functions with proper RLS

### October 29, 2025: Messaging Preparation
- Added `admin` and `team_lead` roles to enum
- Created `can_send_messages()` helper function
- **This is preparation for the messaging feature**

---

## Schema Statistics

- **Total Tables:** 14
- **Total Functions:** 20+
- **Total Views:** 3
- **Total RLS Policies:** 40+
- **Total Indexes:** 25+
- **Total Triggers:** 8
- **Storage Buckets:** 1 (project-files)

---

## Next Steps: Messaging Implementation

The current schema is ready for the messaging feature implementation. Required additions:

1. **New Tables:**
   - `departments`: Organizational structure
   - `message_threads`: Conversation threads
   - `messages`: Individual messages
   - `message_recipients`: Many-to-many messages ↔ users
   - `message_groups`: Saved broadcast lists

2. **New Columns:**
   - `profiles.department_id`: Department membership
   - `profiles.reports_to`: Hierarchical reporting

3. **New Functions:**
   - `can_message_user(sender_id, recipient_id)`: Permission check

4. **New RLS Policies:**
   - Message visibility based on sender/recipient
   - Department-scoped permissions
   - Audit trail preservation

---

**End of Document**
