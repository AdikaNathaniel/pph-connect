-- ============================================================================
-- MAESTRO WORKBENCH - BASELINE SCHEMA (FUNCTIONS ONLY)
-- ============================================================================
--
-- Created: 2025-10-29
-- Purpose: All database functions for reference and documentation
-- Total Functions: 20+
--
-- Categories:
--   1. Utility Functions
--   2. Security Helper Functions
--   3. User Management Functions
--   4. ID Generation Functions
--   5. Task & Question Management Functions
--   6. Analytics Functions
--
-- ============================================================================

-- ============================================================================
-- CATEGORY 1: UTILITY FUNCTIONS
-- ============================================================================

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- ============================================================================
-- CATEGORY 2: SECURITY HELPER FUNCTIONS
-- ============================================================================
-- These functions prevent RLS recursion by using SECURITY DEFINER
-- ============================================================================

-- Check if user is root
CREATE OR REPLACE FUNCTION public.is_root(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = _user_id AND role = 'root'
    );
$$;

-- Check if user is root or manager
CREATE OR REPLACE FUNCTION public.is_root_or_manager(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = _user_id AND role IN ('root', 'manager')
    );
$$;

-- Check if user can send messages
CREATE OR REPLACE FUNCTION public.can_send_messages(_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = _user_id
        AND role IN ('root', 'admin', 'manager', 'team_lead', 'worker')
        AND suspended = false
    );
END;
$$;

-- ============================================================================
-- CATEGORY 3: USER MANAGEMENT FUNCTIONS
-- ============================================================================

-- Handle new user creation (trigger function)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, role)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role, 'worker')
    );
    RETURN NEW;
END;
$$;

-- Create user invitation with hashed password
CREATE OR REPLACE FUNCTION public.create_user_invitation(
    _email TEXT,
    _role public.user_role,
    _initial_password TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invitation_id UUID;
    password_hash TEXT;
BEGIN
    -- Only root and managers can create invitations
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role IN ('root', 'manager')
    ) THEN
        RAISE EXCEPTION 'Only root users and managers can create invitations';
    END IF;

    -- Hash password using pgcrypto
    password_hash := crypt(_initial_password, gen_salt('bf'));

    -- Insert invitation
    INSERT INTO public.user_invitations (email, role, invited_by, initial_password_hash)
    VALUES (_email, _role, auth.uid(), password_hash)
    RETURNING id INTO invitation_id;

    RETURN invitation_id;
END;
$$;

-- Update user last sign-in timestamp
CREATE OR REPLACE FUNCTION public.mark_last_sign_in()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    UPDATE public.profiles
    SET last_sign_in_at = now()
    WHERE id = auth.uid();
END;
$$;

-- Enforce role update restrictions (trigger function)
CREATE OR REPLACE FUNCTION public.enforce_role_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Only root can assign root role
    IF NEW.role = 'root' AND NOT public.is_root(auth.uid()) THEN
        RAISE EXCEPTION 'Only root can assign the root role';
    END IF;
    RETURN NEW;
END;
$$;

-- ============================================================================
-- CATEGORY 4: ID GENERATION FUNCTIONS
-- ============================================================================

-- Generate unique question ID
-- Format: 24char+project_name+24char
CREATE OR REPLACE FUNCTION public.generate_question_id(project_name TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
    prefix TEXT;
    suffix TEXT;
    clean_name TEXT;
BEGIN
    prefix := substring(md5(random()::text || clock_timestamp()::text) from 1 for 24);
    suffix := substring(md5(random()::text || clock_timestamp()::text) from 1 for 24);

    clean_name := regexp_replace(project_name, '[^a-zA-Z0-9]', '', 'g');
    clean_name := substring(clean_name from 1 for 50);

    RETURN prefix || '+' || clean_name || '+' || suffix;
END;
$$;

-- Generate unique answer ID
-- Format: 24char+project_name+answer+24char
CREATE OR REPLACE FUNCTION public.generate_answer_id(question_id TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
    prefix TEXT;
    suffix TEXT;
    project_name TEXT;
    clean_name TEXT;
BEGIN
    project_name := split_part(question_id, '+', 2);
    prefix := substring(question_id from 1 for 24);
    suffix := substring(md5(random()::text || clock_timestamp()::text) from 1 for 24);

    clean_name := regexp_replace(project_name, '[^a-zA-Z0-9]', '', 'g');
    clean_name := substring(clean_name from 1 for 50);

    RETURN prefix || '+' || clean_name || '+answer+' || suffix;
END;
$$;

-- ============================================================================
-- CATEGORY 5: TASK & QUESTION MANAGEMENT FUNCTIONS
-- ============================================================================

-- Update question completion status (trigger function)
CREATE OR REPLACE FUNCTION public.update_question_completion()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE public.questions
    SET
        completed_replications = (
            SELECT COUNT(*) FROM public.answers
            WHERE question_id = NEW.question_id
        ),
        is_answered = (
            SELECT COUNT(*) >= required_replications
            FROM public.answers
            WHERE question_id = NEW.question_id
        ),
        updated_at = now()
    WHERE id = NEW.question_id;

    RETURN NEW;
END;
$$;

-- Clean up expired reservations
CREATE OR REPLACE FUNCTION public.cleanup_expired_reservations()
RETURNS INTEGER
LANGUAGE plpgsql
AS $$
DECLARE
    cleaned_count INTEGER;
BEGIN
    UPDATE public.tasks t
    SET status = 'pending',
        assigned_to = NULL,
        assigned_at = NULL
    FROM public.projects p
    WHERE t.project_id = p.id
      AND t.status IN ('assigned', 'in_progress')
      AND t.assigned_at < NOW() - MAKE_INTERVAL(mins => GREATEST(COALESCE(NULLIF(p.reservation_time_limit_minutes, 0), 60), 1));

    GET DIAGNOSTICS cleaned_count = ROW_COUNT;
    RETURN cleaned_count;
END;
$$;

-- Release all tasks for current worker
CREATE OR REPLACE FUNCTION public.release_worker_tasks()
RETURNS TABLE(
    released_count INTEGER,
    released_task_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    released_ids UUID[];
    count_released INTEGER;
BEGIN
    SELECT ARRAY_AGG(id)
    INTO released_ids
    FROM public.tasks
    WHERE assigned_to = auth.uid()
      AND status IN ('assigned', 'in_progress');

    UPDATE public.tasks
    SET status = 'pending',
        assigned_to = NULL,
        assigned_at = NULL,
        updated_at = NOW()
    WHERE assigned_to = auth.uid()
      AND status IN ('assigned', 'in_progress');

    GET DIAGNOSTICS count_released = ROW_COUNT;

    RETURN QUERY SELECT count_released, COALESCE(released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Release specific task by ID
CREATE OR REPLACE FUNCTION public.release_task_by_id(p_task_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    task_exists BOOLEAN;
BEGIN
    SELECT EXISTS(
        SELECT 1 FROM public.tasks
        WHERE id = p_task_id
          AND assigned_to = auth.uid()
          AND status IN ('assigned', 'in_progress')
    ) INTO task_exists;

    IF NOT task_exists THEN
        RETURN FALSE;
    END IF;

    UPDATE public.tasks
    SET status = 'pending',
        assigned_to = NULL,
        assigned_at = NULL,
        updated_at = NOW()
    WHERE id = p_task_id
      AND assigned_to = auth.uid()
      AND status IN ('assigned', 'in_progress');

    RETURN TRUE;
END;
$$;

-- Count available questions for claiming
CREATE OR REPLACE FUNCTION public.count_claimable_questions(p_project_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    claimable_count INTEGER;
    reservation_time_limit INTEGER;
BEGIN
    -- Get project reservation time limit
    SELECT COALESCE(reservation_time_limit_minutes, 60)
    INTO reservation_time_limit
    FROM public.projects
    WHERE id = p_project_id;

    -- Count questions that can be claimed
    SELECT COUNT(*)::INTEGER
    INTO claimable_count
    FROM public.questions q
    WHERE q.project_id = p_project_id
      AND q.is_answered = false
      AND q.completed_replications < q.required_replications
      AND NOT EXISTS (
          SELECT 1 FROM public.tasks t
          WHERE t.question_id = q.id
            AND t.status IN ('assigned', 'in_progress')
            AND t.assigned_at >= NOW() - MAKE_INTERVAL(mins => reservation_time_limit)
      );

    RETURN claimable_count;
END;
$$;

-- Count active reservations for worker
CREATE OR REPLACE FUNCTION public.count_active_reservations_for_worker(
    p_project_id UUID,
    p_worker_id UUID
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    active_count INTEGER;
    reservation_time_limit INTEGER;
BEGIN
    -- Get project reservation time limit
    SELECT COALESCE(reservation_time_limit_minutes, 60)
    INTO reservation_time_limit
    FROM public.projects
    WHERE id = p_project_id;

    -- Count active reservations
    SELECT COUNT(*)::INTEGER
    INTO active_count
    FROM public.tasks
    WHERE project_id = p_project_id
      AND assigned_to = p_worker_id
      AND status IN ('assigned', 'in_progress')
      AND assigned_at >= NOW() - MAKE_INTERVAL(mins => reservation_time_limit);

    RETURN active_count;
END;
$$;

-- Claim next available question (CORE FUNCTION - Complex logic)
-- This is the main task claiming function with atomic operations
CREATE OR REPLACE FUNCTION public.claim_next_available_question(
    p_project_id UUID,
    p_worker_id UUID
)
RETURNS TABLE(
    id UUID,
    project_id UUID,
    question_id TEXT,
    row_index INTEGER,
    data JSONB,
    completed_replications INTEGER,
    required_replications INTEGER,
    is_answered BOOLEAN,
    created_at TIMESTAMPTZ,
    reservation_task_id UUID
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_question_record RECORD;
    v_task_id UUID;
    v_reservation_time_limit INTEGER;
    v_existing_reservation_task_id UUID;
    v_existing_reservation_project_id UUID;
BEGIN
    -- Get project reservation time limit
    SELECT COALESCE(reservation_time_limit_minutes, 60)
    INTO v_reservation_time_limit
    FROM public.projects
    WHERE id = p_project_id;

    -- Clean up expired reservations for this worker across all projects
    UPDATE public.tasks t
    SET status = 'pending',
        assigned_to = NULL,
        assigned_at = NULL
    FROM public.projects p
    WHERE t.project_id = p.id
      AND t.assigned_to = p_worker_id
      AND t.status IN ('assigned', 'in_progress')
      AND t.assigned_at < NOW() - MAKE_INTERVAL(mins => GREATEST(COALESCE(NULLIF(p.reservation_time_limit_minutes, 0), 60), 1));

    -- Check if worker already has an active reservation for THIS project
    SELECT t.id, t.project_id
    INTO v_existing_reservation_task_id, v_existing_reservation_project_id
    FROM public.tasks t
    JOIN public.projects p ON t.project_id = p.id
    WHERE t.assigned_to = p_worker_id
      AND t.status IN ('assigned', 'in_progress')
      AND t.assigned_at >= NOW() - MAKE_INTERVAL(mins => GREATEST(COALESCE(NULLIF(p.reservation_time_limit_minutes, 0), 60), 1))
      AND t.project_id = p_project_id
    LIMIT 1;

    -- If worker has existing reservation for this project, return it
    IF v_existing_reservation_task_id IS NOT NULL THEN
        RETURN QUERY
        SELECT
            q.id,
            q.project_id,
            q.question_id,
            q.row_index,
            q.data,
            q.completed_replications,
            q.required_replications,
            q.is_answered,
            q.created_at,
            v_existing_reservation_task_id AS reservation_task_id
        FROM public.questions q
        JOIN public.tasks t ON t.question_id = q.id
        WHERE t.id = v_existing_reservation_task_id;
        RETURN;
    END IF;

    -- Check if worker has active reservation for DIFFERENT project (block new claim)
    SELECT t.id
    INTO v_existing_reservation_task_id
    FROM public.tasks t
    JOIN public.projects p ON t.project_id = p.id
    WHERE t.assigned_to = p_worker_id
      AND t.status IN ('assigned', 'in_progress')
      AND t.assigned_at >= NOW() - MAKE_INTERVAL(mins => GREATEST(COALESCE(NULLIF(p.reservation_time_limit_minutes, 0), 60), 1))
      AND t.project_id != p_project_id
    LIMIT 1;

    -- If worker has reservation for different project, return empty
    IF v_existing_reservation_task_id IS NOT NULL THEN
        RETURN;
    END IF;

    -- Clean up expired reservations for target project
    UPDATE public.tasks t
    SET status = 'pending',
        assigned_to = NULL,
        assigned_at = NULL
    WHERE t.project_id = p_project_id
      AND t.status IN ('assigned', 'in_progress')
      AND t.assigned_at < NOW() - MAKE_INTERVAL(mins => v_reservation_time_limit);

    -- Find next available question with row-level locking
    SELECT q.*
    INTO v_question_record
    FROM public.questions q
    WHERE q.project_id = p_project_id
      AND q.is_answered = false
      AND q.completed_replications < q.required_replications
      AND NOT EXISTS (
          SELECT 1 FROM public.tasks t
          WHERE t.question_id = q.id
            AND t.status IN ('assigned', 'in_progress')
            AND t.assigned_at >= NOW() - MAKE_INTERVAL(mins => v_reservation_time_limit)
      )
    ORDER BY q.row_index
    LIMIT 1
    FOR UPDATE SKIP LOCKED;

    -- If no question found, return empty
    IF v_question_record.id IS NULL THEN
        RETURN;
    END IF;

    -- Create task reservation
    INSERT INTO public.tasks (
        project_id,
        question_id,
        row_index,
        data,
        status,
        assigned_to,
        assigned_at
    )
    VALUES (
        p_project_id,
        v_question_record.id,
        v_question_record.row_index,
        v_question_record.data,
        'assigned',
        p_worker_id,
        NOW()
    )
    RETURNING id INTO v_task_id;

    -- Return question data with reservation task ID
    RETURN QUERY
    SELECT
        v_question_record.id,
        v_question_record.project_id,
        v_question_record.question_id,
        v_question_record.row_index,
        v_question_record.data,
        v_question_record.completed_replications,
        v_question_record.required_replications,
        v_question_record.is_answered,
        v_question_record.created_at,
        v_task_id AS reservation_task_id;
END;
$$;

-- ============================================================================
-- CATEGORY 6: ANALYTICS FUNCTIONS
-- ============================================================================

-- Get project completion statistics
CREATE OR REPLACE FUNCTION public.get_project_completion_stats(project_uuid UUID)
RETURNS TABLE(
    total_questions INTEGER,
    answered_questions INTEGER,
    completion_percentage NUMERIC
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(*)::INTEGER as total_questions,
        COUNT(*) FILTER (WHERE is_answered = true)::INTEGER as answered_questions,
        CASE
            WHEN COUNT(*) = 0 THEN 0
            ELSE ROUND((COUNT(*) FILTER (WHERE is_answered = true)::NUMERIC / COUNT(*)::NUMERIC) * 100, 2)
        END as completion_percentage
    FROM public.questions
    WHERE project_id = project_uuid;
END;
$$;

-- ============================================================================
-- FUNCTION SUMMARY
-- ============================================================================
--
-- Total Functions: 20
--
-- Utility (1):
--   - update_updated_at_column()
--
-- Security Helpers (3):
--   - is_root(uuid)
--   - is_root_or_manager(uuid)
--   - can_send_messages(uuid)
--
-- User Management (4):
--   - handle_new_user()
--   - create_user_invitation(text, user_role, text)
--   - mark_last_sign_in()
--   - enforce_role_update()
--
-- ID Generation (2):
--   - generate_question_id(text)
--   - generate_answer_id(text)
--
-- Task & Question Management (9):
--   - update_question_completion()
--   - cleanup_expired_reservations()
--   - release_worker_tasks()
--   - release_task_by_id(uuid)
--   - count_claimable_questions(uuid)
--   - count_active_reservations_for_worker(uuid, uuid)
--   - claim_next_available_question(uuid, uuid) [CORE FUNCTION]
--
-- Analytics (1):
--   - get_project_completion_stats(uuid)
--
-- ============================================================================
-- END
-- ============================================================================
